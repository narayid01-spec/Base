# VEdit Pro Android — sumber v1.1

Projek Android native menggunakan Kotlin, Jetpack Compose dan AndroidX Media3 Transformer.

## Fungsi yang dilaksanakan dalam versi ini
- Pilih video melalui pemilih fail Android
- Pratonton video dengan kawalan pemain
- Trim menggunakan masa mula dan akhir dalam saat
- Kelajuan eksport 0.25x hingga 2x
- Eksport MP4 ke folder Movies/VEditPro
- GitHub Actions untuk membina APK debug

## Bina APK melalui telefon
1. Muat turun dan ekstrak ZIP ini.
2. Muat naik semua KANDUNGAN projek (bukan ZIP sahaja) ke root repository GitHub, termasuk `app/`, `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, dan `.github/workflows/android.yml`.
3. Buka tab Actions dan jalankan `Build VEdit Pro APK`.
4. Jika berjaya, buka run dan muat turun artifact `VEditPro-debug-apk`.
5. Ekstrak ZIP artifact dan pasang `app-debug.apk`.

Workflow turut boleh mengekstrak `VEditPro-Android.zip` di root jika fail projek belum ada di root. Namun, kaedah yang disyorkan ialah memuat naik kandungan projek ke root supaya mudah disemak.

## Belum dilaksanakan
Teks overlay, muzik latar, timeline berbilang klip/lapisan, keyframe animasi, filter, transisi, undo/redo dan pemilihan resolusi 720p/1080p/4K belum disertakan. Projek ini ialah asas yang boleh dibina dan dikembangkan, bukan pengganti penuh CapCut/Alight Motion.
