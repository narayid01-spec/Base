package com.veditpro.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Film
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.Effects
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.ui.PlayerView
import java.io.File

private val Background = Color(0xFF101018)
private val Panel = Color(0xFF1B1B28)
private val Accent = Color(0xFF9B72FF)
private val MainText = Color(0xFFF4F1FF)

class MainActivity : ComponentActivity() {
    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VEditProScreen() }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun VEditProScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var startText by remember { mutableStateOf("0") }
    var endText by remember { mutableStateOf("10") }
    var speed by remember { mutableFloatStateOf(1f) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Pilih video untuk mula.") }
    var player by remember { mutableStateOf<ExoPlayer?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            videoUri = uri
            status = "Video dimuatkan. Tetapkan trim dan kelajuan, kemudian eksport."
        }
    }

    DisposableEffect(videoUri) {
        val selected = videoUri
        val newPlayer = if (selected != null) ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(selected))
            prepare()
            playWhenReady = false
        } else null
        player = newPlayer
        onDispose { newPlayer?.release() }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Background, surface = Panel, onSurface = MainText)) {
        Column(
            Modifier.fillMaxSize().background(Background).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Film, null, tint = Accent, modifier = Modifier.size(36.dp))
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("VEdit Pro", color = MainText, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("Free video editor • Android", color = Color.LightGray, fontSize = 13.sp)
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("VIDEO PREVIEW", color = Accent, fontWeight = FontWeight.Bold)
                    if (player != null) {
                        AndroidView(
                            factory = { ctx -> PlayerView(ctx).apply { player = this@VEditProScreen.player; useController = true } },
                            update = { it.player = player },
                            modifier = Modifier.fillMaxWidth().height(220.dp)
                        )
                    } else {
                        Box(Modifier.fillMaxWidth().height(180.dp).background(Color(0xFF292638), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.VideoLibrary, null, tint = Accent, modifier = Modifier.size(42.dp))
                                Spacer(Modifier.height(8.dp))
                                Text("Belum ada video", color = MainText)
                            }
                        }
                    }
                    Button(onClick = { picker.launch("video/*") }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.VideoLibrary, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Pilih video")
                    }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ContentCut, null, tint = Accent)
                        Spacer(Modifier.width(8.dp))
                        Text("Trim video", color = MainText, fontWeight = FontWeight.Bold)
                    }
                    Text("Masukkan masa mula dan akhir dalam saat.", color = Color.LightGray, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(startText, { startText = it.filter(Char::isDigit).take(6) }, label = { Text("Mula (s)") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(endText, { endText = it.filter(Char::isDigit).take(6) }, label = { Text("Akhir (s)") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Speed, null, tint = Accent)
                        Spacer(Modifier.width(8.dp))
                        Text("Kelajuan: ${"%.2f".format(speed)}×", color = MainText)
                    }
                    Slider(value = speed, onValueChange = { speed = it }, valueRange = 0.25f..2f, steps = 6)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("0.25×", color = Color.LightGray, fontSize = 12.sp)
                        Text("1× normal", color = Color.LightGray, fontSize = 12.sp)
                        Text("2×", color = Color.LightGray, fontSize = 12.sp)
                    }
                    Button(
                        onClick = {
                            val uri = videoUri
                            val start = startText.toLongOrNull()
                            val end = endText.toLongOrNull()
                            when {
                                uri == null -> status = "Sila pilih video dahulu."
                                start == null || end == null || end <= start -> status = "Masa tidak sah. Masa akhir mesti lebih besar daripada masa mula."
                                else -> exportVideo(context, uri, start * 1000, end * 1000, speed,
                                    onStart = { busy = true; status = "Sedang mengeksport MP4. Jangan tutup aplikasi." },
                                    onDone = { busy = false; status = "Eksport berjaya. Disimpan dalam Movies/VEditPro." },
                                    onError = { msg -> busy = false; status = "Eksport gagal: $msg" })
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                        else Text("Eksport MP4")
                    }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("STATUS", color = Accent, fontWeight = FontWeight.Bold)
                    Text(status, color = MainText)
                }
            }

            Text("Versi 1.1: import, pratonton, trim dan ubah kelajuan ketika eksport. Ciri lapisan animasi, keyframe, teks, muzik, filter, transisi dan eksport 4K belum dilaksanakan dalam versi ini.", color = Color.LightGray, fontSize = 12.sp)
        }
    }
}

@OptIn(UnstableApi::class)
private fun exportVideo(
    context: Context,
    inputUri: Uri,
    startMs: Long,
    endMs: Long,
    speed: Float,
    onStart: () -> Unit,
    onDone: () -> Unit,
    onError: (String) -> Unit
) {
    var outputFile: File? = null
    try {
        val directory = File(context.cacheDir, "vedit_exports").apply { mkdirs() }
        outputFile = File(directory, "vedit_${System.currentTimeMillis()}.mp4")
        val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(startMs)
            .setEndPositionMs(endMs)
            .build()
        val item = MediaItem.Builder().setUri(inputUri).setClippingConfiguration(clip).build()
        val effects = Effects(emptyList(), listOf(SpeedChangeEffect(speed)))
        val edited = EditedMediaItem.Builder(item).setEffects(effects).build()
        val destination = outputFile
        val transformer = Transformer.Builder(context)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    try {
                        val values = ContentValues().apply {
                            put(MediaStore.Video.Media.DISPLAY_NAME, destination.name)
                            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VEditPro")
                        }
                        val outputUri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                        if (outputUri == null) {
                            onError("Tidak dapat mencipta fail output dalam galeri.")
                            destination.delete()
                            return
                        }
                        context.contentResolver.openOutputStream(outputUri)?.use { out ->
                            destination.inputStream().use { input -> input.copyTo(out) }
                        } ?: throw IllegalStateException("Tidak dapat membuka lokasi simpanan.")
                        destination.delete()
                        onDone()
                    } catch (e: Exception) {
                        destination.delete()
                        onError(e.message ?: "Tidak dapat menyimpan fail.")
                    }
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    destination.delete()
                    onError(exportException.message ?: "Ralat pemprosesan video.")
                }
            }).build()
        onStart()
        transformer.start(edited, destination.absolutePath)
    } catch (e: Exception) {
        outputFile?.delete()
        onError(e.message ?: "Ralat tidak diketahui.")
    }
}
