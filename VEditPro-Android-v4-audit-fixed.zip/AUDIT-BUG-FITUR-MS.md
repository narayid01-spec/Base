# VEdit Pro — Audit statik dan senarai fitur

Tarikh audit: 10 Oktober 2026  
Sumber diaudit: projek VEdit Pro v1.1 dalam pakej v3.

## Skop dan had audit

Ini ialah **semakan kod secara statik**. Persekitaran ini tidak mempunyai Gradle/Android SDK untuk menjalankan binaan Android, jadi saya tidak boleh mengesahkan bahawa APK berjaya dikompilasi atau diuji pada telefon. Bug yang dinyatakan sebagai “disahkan daripada kod” jelas kelihatan daripada sumber; kemungkinan isu lain memerlukan binaan dan ujian sebenar.

## Penemuan utama

### B1 — Rujukan pemain video pada paparan pratonton (dibetulkan dalam pakej ini)
Kod asal menggunakan `this@VEditProScreen.player` dalam lambda `apply` pada `PlayerView`. Itu bukan rujukan receiver Kotlin yang sah untuk mendapatkan state composable. Ia diganti dengan pembolehubah tempatan `previewPlayer`, lalu diberikan kepada `PlayerView.player`. Perlu disahkan melalui kompilasi sebenar.

### B2 — Tiada semakan bahawa masa akhir berada dalam durasi video
Aplikasi hanya memeriksa `end > start`. Jika masa akhir melebihi durasi sebenar, eksport mungkin gagal. Perlu bandingkan dengan `player.duration`/metadata dan tunjuk ralat yang jelas.

### B3 — Nilai masa hanya integer saat
Pengguna tidak boleh memilih milisaat atau masa dengan format mm:ss. Trim tidak tepat untuk penyuntingan bingkai demi bingkai.

### B4 — Slider kelajuan boleh memberi gambaran kawalan lebih tepat daripada implementasi
Kelajuan ditetapkan ketika eksport, bukan perubahan kelajuan masa nyata pada pratonton. UI patut menyatakan perkara ini dengan jelas.

### B5 — Tiada kemajuan eksport sebenar
UI hanya menunjukkan spinner. Tiada peratusan kemajuan atau anggaran masa; pembatalan eksport belum disediakan.

### B6 — Risiko fail MediaStore tertinggal
Jika salinan fail sementara ke MediaStore gagal selepas rekod output dicipta, kod tidak memadam rekod output yang separa. Ia patut memadam URI output dalam blok ralat.

### B7 — Lokasi output pada Android lama tidak dijamin
`RELATIVE_PATH` hanya ditetapkan pada Android 10/API 29 ke atas. Pada Android 7–9, kod tidak menetapkan laluan Movies/VEditPro secara khusus. Perlu implementasi storan berbeza untuk API lama atau nyatakan lokasi sebenar.

### B8 — Kegagalan import tidak dipaparkan secara menyeluruh
Pemilih membenarkan pemilihan fail, tetapi UI tidak mengendalikan semua kes fail tidak disokong, URI tamat tempoh, codec tidak serasi atau metadata tidak boleh dibaca sebelum eksport.

### B9 — Projek tidak disimpan
Tiada model projek atau pangkalan data. Jika aplikasi ditutup, pemilihan media dan tetapan suntingan tidak dipulihkan.

### B10 — Had saiz/format dan codec tidak diuji
4K, HDR, HEVC, variable frame rate, fail besar dan ruang storan rendah belum diuji. Tiada jaminan bahawa semua format telefon boleh dieksport.

### B11 — Tiada pilihan resolusi atau FPS
Eksport menggunakan konfigurasi lalai Transformer. UI belum membolehkan pengguna memilih 720p, 1080p, 1440p, 4K atau frame rate.

### B12 — Tiada pembatalan dan pemulihan proses
Tiada butang batal; jika aplikasi ditutup semasa eksport, fail sementara boleh tertinggal.

### B13 — Workflow GitHub hanya mengesahkan jika struktur ZIP tepat
Workflow mengandaikan nama ZIP `VEditPro-Android.zip` di root apabila fail projek tidak ada di root. Nama berbeza atau ZIP mengandungi satu folder pembungkus tambahan boleh menyebabkan `gradle assembleDebug` gagal. Muat naik kandungan projek terus ke root repositori lebih boleh dipercayai.

### B14 — Workflow belum membuktikan binaan berjaya
Artifact hanya tersedia jika Gradle build dan upload berjaya. Status hijau pada workflow lama yang sekadar `echo Hello, world!` bukan bukti APK telah dihasilkan.

### B15 — Kebergantungan/API perlu disahkan
Versi Android Gradle Plugin, Kotlin, Compose dan Media3 dikunci dalam fail build. Keserasian tepat serta signature API perlu disahkan melalui Gradle compile; audit ini tidak menjalankan compile.

## Fitur yang memang dikodkan dalam versi asas

1. Pilih satu video menggunakan Android file picker.
2. Pratonton video dengan ExoPlayer/PlayerView.
3. Main/jeda melalui kawalan PlayerView.
4. Masukkan masa mula trim dalam saat.
5. Masukkan masa akhir trim dalam saat.
6. Laraskan kelajuan eksport antara 0.25× hingga 2×.
7. Jalankan trim dan speed effect melalui Media3 Transformer.
8. Eksport ke fail MP4 sementara.
9. Cuba simpan hasil ke MediaStore/Movies/VEditPro.
10. Paparkan status asas dan mesej ralat eksport.
11. Tema gelap dan susun atur Compose yang boleh diskrol.
12. Workflow GitHub Actions untuk cuba membina debug APK dan memuat naik artifact.

Semua ciri ini masih perlu ujian runtime. Senarai di atas menerangkan apa yang ada dalam kod, bukan jaminan bahawa semuanya lulus pada setiap peranti.

## Fitur yang belum dilaksanakan

- Timeline visual dan berbilang klip.
- Track/lapisan video, imej, teks dan audio.
- Drag-and-drop susunan klip.
- Split, ripple delete, snapping dan zoom timeline.
- Import berbilang fail dan pengurusan media projek.
- Muzik latar, rakaman suara, waveform, fade dan mixing.
- Teks overlay, font, outline, shadow, sticker, shapes dan sari kata.
- Keyframe position/scale/rotation/opacity/volume.
- Easing curves, graph editor dan animasi masuk/keluar.
- Crop UI, flip, ratio preset dan canvas background.
- Filter/colour correction seperti brightness, contrast, saturation, temperature dan tint.
- Blur, vignette, sharpen dan preset kesan.
- Transisi fade/dissolve dan kawalan durasinya.
- Picture-in-picture dan komposisi multi-layer.
- Pilihan resolusi, FPS, bitrate dan preset eksport 4K.
- Simpan/buka projek, auto-save, undo/redo dan project history.
- Kemajuan eksport sebenar, batal, retry dan cleanup fail.
- Pilihan bahasa/tema penuh, tutorial dan tetapan.
- Ujian automatik, ujian peranti, analitik prestasi dan pemeriksaan codec.

## Senarai 220 fitur sasaran

Senarai penuh beserta kotak semak dan pengelompokan modul berada dalam `FEATURE-ROADMAP-MS.md`. Ia ialah backlog sasaran, bukan 220 fitur yang sudah aktif.

## Ujian yang perlu dilakukan sebelum keluaran APK

1. `gradle assembleDebug` mesti lulus.
2. Pasang APK pada telefon Android sebenar.
3. Import video pendek MP4 H.264, main/jeda, trim dan eksport.
4. Uji masa akhir melebihi durasi; aplikasi mesti memberi mesej yang betul, bukan crash.
5. Uji video dengan audio dan tanpa audio.
6. Uji fail besar dan ruang storan rendah.
7. Pastikan hasil eksport boleh dimainkan di galeri.
8. Uji Android API 24–28 serta API 29+ jika menyokong versi tersebut.
9. Uji fail yang tidak disokong dan URI yang tidak lagi boleh diakses.
10. Semak bahawa tiada fail sementara atau rekod output rosak tertinggal selepas ralat.

## Kesimpulan

Versi ini ialah prototaip awal, bukan editor penuh seperti CapCut atau Alight Motion. Bug rujukan `PlayerView` telah diperbaiki dalam kod pakej ini, tetapi **pembaikan itu belum disahkan dengan kompilasi**. Jangan anggap APK siap atau stabil sehingga workflow sebenar berjaya dan ujian peranti dilakukan.
