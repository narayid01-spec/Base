# VEdit Pro — Pelan 180 Fitur

Dokumen ini ialah pelan pembangunan terperinci. Ia **tidak bermaksud semua fitur telah siap dilaksanakan**. Versi sumber semasa hanya mempunyai import video, pratonton, trim, pelarasan kelajuan eksport dan eksport MP4 asas; setiap fungsi mesti dibina dan diuji sebelum ditandakan siap.

## Status versi semasa
- [x] Pilih satu video melalui pemilih Android
- [x] Pratonton video dengan kawalan pemain
- [x] Trim melalui masa mula dan akhir
- [x] Tetapkan kelajuan eksport antara 0.25x hingga 2x
- [x] Kod eksport MP4 dan simpan ke Movies/VEditPro (perlu diuji pada peranti)
- [ ] Timeline berbilang trek, overlay sebenar, keyframe, teks, muzik, filter, transisi, simpan projek dan pilihan 4K belum siap

## Senarai fitur sasaran
Jumlah item dalam backlog: **220**. Fitur disusun mengikut modul supaya boleh dibangunkan secara berperingkat.

### Import & Media
1. [ ] Import video daripada galeri
2. [ ] Import beberapa video sekali gus
3. [ ] Import audio daripada peranti
4. [ ] Import imej sebagai klip
5. [ ] Import GIF jika format disokong
6. [ ] Pilih fail melalui Android Photo Picker
7. [ ] Paparkan nama fail sumber
8. [ ] Paparkan durasi media
9. [ ] Paparkan resolusi media
10. [ ] Paparkan kadar bingkai media
11. [ ] Paparkan saiz fail media
12. [ ] Semak format media yang disokong
13. [ ] Mesej ralat fail rosak
14. [ ] Kendalikan fail yang tidak boleh dibaca
15. [ ] Sokongan URI storan Android

### Timeline & Klip
16. [ ] Timeline visual
17. [ ] Tambah klip video ke projek
18. [ ] Tambah klip imej ke projek
19. [ ] Susun semula klip
20. [ ] Padam klip terpilih
21. [ ] Duplikasi klip
22. [ ] Potong permulaan klip
23. [ ] Potong penghujung klip
24. [ ] Tetapkan masa mula secara angka
25. [ ] Tetapkan masa akhir secara angka
26. [ ] Paparan durasi projek
27. [ ] Penanda playhead
28. [ ] Navigasi timeline
29. [ ] Zum masuk timeline
30. [ ] Zum keluar timeline
31. [ ] Pilih klip aktif
32. [ ] Simpan susunan klip
33. [ ] Kunci klip daripada perubahan
34. [ ] Sembunyikan trek
35. [ ] Pisahkan klip di playhead

### Audio
36. [ ] Tambah trek muzik latar
37. [ ] Pratonton audio
38. [ ] Laraskan volum trek
39. [ ] Laraskan volum klip asal
40. [ ] Mute audio klip
41. [ ] Fade-in audio
42. [ ] Fade-out audio
43. [ ] Potong audio
44. [ ] Loop audio latar
45. [ ] Alih kedudukan audio dalam timeline
46. [ ] Tambah beberapa trek audio
47. [ ] Rakaman suara latar
48. [ ] Paparkan waveform audio
49. [ ] Simpan audio asal apabila trim
50. [ ] Kawal audio bagi setiap klip

### Teks & Grafik
51. [ ] Tambah teks pada video
52. [ ] Edit kandungan teks
53. [ ] Pilih saiz teks
54. [ ] Pilih warna teks
55. [ ] Pilih warna latar teks
56. [ ] Pilih penjajaran teks
57. [ ] Ubah kedudukan teks
58. [ ] Ubah tempoh paparan teks
59. [ ] Tambah outline teks
60. [ ] Tambah bayang teks
61. [ ] Tambah sticker daripada fail tempatan
62. [ ] Tambah bentuk asas
63. [ ] Tambah emoji sebagai overlay
64. [ ] Duplikasi lapisan teks
65. [ ] Padam lapisan teks

### Animasi & Keyframe
66. [ ] Keyframe posisi X
67. [ ] Keyframe posisi Y
68. [ ] Keyframe skala
69. [ ] Keyframe putaran
70. [ ] Keyframe kelegapan
71. [ ] Keyframe volum audio
72. [ ] Animasi masuk teks
73. [ ] Animasi keluar teks
74. [ ] Interpolasi linear
75. [ ] Interpolasi ease-in
76. [ ] Interpolasi ease-out
77. [ ] Interpolasi ease-in-out
78. [ ] Paparan keyframe pada timeline
79. [ ] Edit masa keyframe
80. [ ] Padam keyframe
81. [ ] Duplikasi keyframe
82. [ ] Pratonton animasi
83. [ ] Animasi skala objek
84. [ ] Animasi putaran objek
85. [ ] Animasi pergerakan objek

### Transformasi & Kanvas
86. [ ] Putar video 90 darjah
87. [ ] Flip mendatar
88. [ ] Flip menegak
89. [ ] Pangkas bingkai video
90. [ ] Nisbah aspek 16:9
91. [ ] Nisbah aspek 9:16
92. [ ] Nisbah aspek 1:1
93. [ ] Nisbah aspek 4:5
94. [ ] Kanvas warna latar
95. [ ] Kanvas kabur sebagai latar
96. [ ] Laraskan skala kandungan
97. [ ] Laraskan kedudukan kandungan
98. [ ] Fit video dalam kanvas
99. [ ] Fill kanvas dengan video
100. [ ] Pratonton komposisi kanvas

### Filter & Kesan
101. [ ] Filter grayscale
102. [ ] Laraskan kecerahan
103. [ ] Laraskan kontras
104. [ ] Laraskan ketepuan
105. [ ] Laraskan suhu warna
106. [ ] Laraskan tint
107. [ ] Laraskan pendedahan
108. [ ] Laraskan gamma jika disokong
109. [ ] Kesan blur
110. [ ] Kesan sharpen jika disokong
111. [ ] Vignette
112. [ ] Laraskan intensiti filter
113. [ ] Banding sebelum dan selepas
114. [ ] Reset pelarasan warna
115. [ ] Simpan preset warna

### Transisi & Komposisi
116. [ ] Transisi cut
117. [ ] Transisi fade jika disokong
118. [ ] Transisi dissolve jika disokong
119. [ ] Tempoh transisi boleh laras
120. [ ] Pratonton transisi
121. [ ] Gambar dalam gambar
122. [ ] Tambah overlay video
123. [ ] Laraskan saiz overlay
124. [ ] Laraskan kedudukan overlay
125. [ ] Laraskan kelegapan overlay
126. [ ] Susun keutamaan lapisan
127. [ ] Paparan komposisi berbilang trek
128. [ ] Campuran audio berbilang trek
129. [ ] Eksport komposisi berbilang trek
130. [ ] Amaran kesan yang tidak disokong

### Kelajuan & Masa
131. [ ] Kelajuan 0.25x
132. [ ] Kelajuan 0.5x
133. [ ] Kelajuan 0.75x
134. [ ] Kelajuan 1x
135. [ ] Kelajuan 1.25x
136. [ ] Kelajuan 1.5x
137. [ ] Kelajuan 2x
138. [ ] Kelajuan boleh laras
139. [ ] Kesan gerak perlahan
140. [ ] Kesan gerak pantas
141. [ ] Paparan durasi selepas perubahan kelajuan
142. [ ] Kekalkan pitch audio jika disokong
143. [ ] Reverse video jika dilaksanakan
144. [ ] Paparan masa semasa
145. [ ] Paparan masa akhir projek

### Eksport & Prestasi
146. [ ] Eksport MP4
147. [ ] Pilihan 720p
148. [ ] Pilihan 1080p
149. [ ] Pilihan 1440p jika disokong
150. [ ] Pilihan 4K jika disokong peranti
151. [ ] Pilihan 24 fps jika disokong
152. [ ] Pilihan 30 fps
153. [ ] Pilihan 60 fps jika disokong
154. [ ] Paparan kemajuan eksport
155. [ ] Pembatalan eksport
156. [ ] Mesej ralat eksport
157. [ ] Simpan ke Movies/VEditPro
158. [ ] Nama fail output automatik
159. [ ] Kongsi video selepas eksport
160. [ ] Semak ruang storan sebelum eksport
161. [ ] Pemprosesan media melalui Media3
162. [ ] Penggunaan codec perkakasan apabila tersedia
163. [ ] Amaran codec tidak serasi
164. [ ] Eksport fail sementara dengan selamat
165. [ ] Bersihkan fail sementara

### Projek & Undo
166. [ ] Cipta projek baharu
167. [ ] Nama projek
168. [ ] Simpan metadata projek
169. [ ] Buka projek tersimpan
170. [ ] Auto-simpan tetapan projek
171. [ ] Undo perubahan
172. [ ] Redo perubahan
173. [ ] Duplikasi projek
174. [ ] Padam projek
175. [ ] Paparkan projek terkini
176. [ ] Simpan tetapan trim
177. [ ] Simpan tetapan kelajuan
178. [ ] Simpan tetapan transformasi
179. [ ] Simpan tetapan lapisan teks
180. [ ] Amaran apabila meninggalkan projek belum disimpan

### Antara Muka & Kebolehcapaian
181. [ ] Tema gelap
182. [ ] Tema cerah
183. [ ] Antara muka responsif telefon
184. [ ] Butang besar untuk sentuhan
185. [ ] Label kawalan yang jelas
186. [ ] Mesej status operasi
187. [ ] Petunjuk ketika tiada media
188. [ ] Dialog pengesahan padam
189. [ ] Petunjuk penggunaan kali pertama
190. [ ] Sokongan skrin kecil
191. [ ] Sokongan orientasi potret
192. [ ] Sokongan orientasi landskap jika sesuai
193. [ ] Paparan nama aplikasi dan versi
194. [ ] Pengendalian ralat tanpa crash
195. [ ] Bahasa Melayu

### Privasi & Keselamatan
196. [ ] Pemprosesan media secara setempat
197. [ ] Tiada akaun diperlukan
198. [ ] Tiada API AI berbayar diperlukan untuk edit asas
199. [ ] Keizinan storan minimum
200. [ ] Pemilihan media dengan Photo Picker
201. [ ] Tiada muat naik automatik ke pelayan
202. [ ] Tiada pengumpulan analitik secara lalai
203. [ ] Jangan simpan kata laluan atau rahsia
204. [ ] Maklumat lesen pustaka pihak ketiga
205. [ ] Dokumentasi had privasi

### Alat Lanjutan
206. [ ] Paparan maklumat codec
207. [ ] Paparan resolusi output
208. [ ] Paparan kadar bingkai output
209. [ ] Paparan saiz fail output
210. [ ] Semakan fail output wujud
211. [ ] Semakan fail output tidak kosong
212. [ ] Log ralat eksport yang boleh disalin
213. [ ] Mod diagnostik asas
214. [ ] Pengesanan ciri codec peranti
215. [ ] Had resolusi berdasarkan peranti
216. [ ] Pratonton kesan sebelum eksport
217. [ ] Preset projek sosial menegak
218. [ ] Preset video landskap
219. [ ] Preset video persegi
220. [ ] Preset eksport tersuai jika disokong

## Cadangan fasa pembangunan
1. **Fasa 1 — Projek dan timeline:** import berbilang klip, susun/padam klip, timeline dan simpan/buka projek.
2. **Fasa 2 — Suntingan asas:** audio latar, teks overlay, crop/ratio, kawalan warna asas dan eksport yang boleh dipilih.
3. **Fasa 3 — Animasi:** lapisan, keyframe, easing dan kawalan masa.
4. **Fasa 4 — Kesan:** filter, transisi dan overlay lebih kompleks.
5. **Fasa 5 — Kualiti:** prestasi, kebolehaksesan, eksport beresolusi tinggi dan ujian peranti.

## Nota teknikal
- AndroidX Media3 Transformer menyokong trim, transformasi dan komposisi beberapa aset, tetapi setiap jenis komposisi mempunyai batasan API dan keserasian peranti.
- Eksport 4K hanya boleh ditawarkan apabila sumber, codec, memori dan pengekod peranti menyokongnya. Ia tidak boleh dijamin pada semua telefon.
- Fitur seperti crossfade atau komposisi kompleks mungkin memerlukan pelaksanaan tambahan; jangan paparkan sebagai siap sebelum diuji.
- GitHub Actions hanya membina projek; ia tidak secara automatik menjadikan fungsi yang belum dikodkan berfungsi.