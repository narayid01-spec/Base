# Mega Property Tycoon 3D — GitHub Project

Projek Godot 4.x untuk prototaip permainan tycoon hartanah offline dan workflow GitHub Actions untuk mencuba mengeksport APK Android.

## Kandungan prototaip
- UI potret untuk telefon, menu utama, mula/resume dan tutorial.
- Papan 20 petak, pembelian hartanah, sewa, cukai, kad peluang/komuniti dan bonus bank.
- Seorang pemain melawan tiga AI asas dengan giliran automatik.
- Pengurusan hartanah asas: pekerja, pembangunan dan jualan kepada bank.
- Dashboard kewangan, pinjaman prototaip dan bayaran hutang.
- Akaun lokal dengan kata laluan di-hash, serta Admin Panel lokal yang meminta anda menetapkan kata laluan sendiri pada penggunaan pertama.
- Autosave dan resume perlawanan lokal.
- GitHub Actions workflow: `.github/workflows/android-apk.yml`.

## Had yang perlu diketahui
Ini **prototaip boleh dimainkan**, bukan versi penuh semua ciri dalam master prompt. Grafik papan sekarang ialah UI 2D bergaya, bukan persekitaran 3D low-poly penuh. Sistem pekerja, perdagangan penuh, kontrak, ekonomi dinamik, liga/store penuh, pemulihan kata laluan dan ujian menyeluruh belum dibina. Jangan anggap projek ini sudah diuji pada peranti Android; jalankan dan uji sebelum diedarkan.

Workflow APK bergantung pada imej CI, Android export templates dan konfigurasi Godot. Jika eksport gagal, semak log Actions dan eksport dari Godot 4.x dengan Android SDK/JDK serta export templates yang serasi. Workflow menghasilkan APK debug untuk ujian, bukan release bertandatangan komersial.

## Cara menjalankan
1. Extract ZIP.
2. Buka Godot 4.x dan pilih **Import**.
3. Pilih `project.godot`.
4. Tekan Play untuk menjalankan prototaip.

## Cara bina APK melalui GitHub
1. Cipta repository GitHub baharu.
2. Muat naik semua kandungan ZIP; kekalkan folder `.github/workflows`.
3. Push ke branch `main` atau `master`.
4. Buka tab **Actions**, pilih **Build Android APK**, kemudian tekan **Run workflow**. Workflow juga berjalan pada push.
5. Jika berjaya, muat turun artifact `MegaPropertyTycoon3D-Android-APK` daripada run tersebut.

## Keselamatan
- Akaun dan save hanya lokal pada peranti dan tidak disegerakkan antara peranti.
- Kata laluan admin tidak ditetapkan dalam source code. Tetapkan sendiri kali pertama melalui Admin Panel.
- E-mel admin yang digunakan sebagai pengenal ialah `zuhairiadam4@gmail.com`; e-mel sahaja bukan bukti identiti.
- Jangan guna kata laluan sebenar yang digunakan pada perkhidmatan lain. Jangan masukkan keystore atau rahsia ke repository awam.
