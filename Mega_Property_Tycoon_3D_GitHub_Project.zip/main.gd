extends Control

const SAVE_PATH := "user://mega_property_save.json"
const SETTINGS_PATH := "user://mpt_settings.cfg"
const ACCOUNTS_PATH := "user://mpt_accounts.cfg"
const ADMIN_EMAIL := "zuhairiadam4@gmail.com"
const START_CASH := 1800
const NAMES := ["Start", "Jalan Mutiara", "Kad Peluang", "Kedai Runcit", "Cukai Bandar", "Stesen Metro", "Apartmen Seri", "Dataran Komuniti", "Restoran Nusa", "Taman Rekreasi", "Penjara", "Menara Niaga", "Kilang Utama", "Kad Komuniti", "Hotel Bayu", "Utiliti Air", "Pasar Raya", "Projek Bandar", "Resort Laguna", "Bank Bandar"]
const TYPES := ["start", "property", "chance", "property", "tax", "utility", "property", "community", "property", "property", "jail", "property", "property", "community", "property", "utility", "property", "chance", "property", "bank"]
const PRICES := [0,180,0,240,0,280,300,0,360,400,0,450,480,0,520,300,560,0,620,0]
const RENTS := [0,30,0,42,0,45,50,0,60,70,0,80,90,0,100,45,110,0,125,0]

var players: Array = []
var properties: Array = []
var current_player := 0
var match_started := false
var busy := false
var current_tab := "board"
var last_message := "Selamat datang ke Mega Property Tycoon 3D."
var active_username := "Pemain"
var language := "ms"
var accounts: Dictionary = {}
var admin_hash := ""
var admin_salt := ""
var shell: VBoxContainer
var content: VBoxContainer
var cash_label: Label
var turn_label: Label

func _ready() -> void:
	_load_local()
	_build_menu()

func _load_local() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SETTINGS_PATH) == OK:
		language = str(cfg.get_value("settings", "language", "ms"))
		admin_hash = str(cfg.get_value("admin", "hash", ""))
		admin_salt = str(cfg.get_value("admin", "salt", ""))
	var ac := ConfigFile.new()
	if ac.load(ACCOUNTS_PATH) == OK:
		accounts = ac.get_value("accounts", "data", {})

func _save_local() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("settings", "language", language)
	cfg.set_value("admin", "hash", admin_hash)
	cfg.set_value("admin", "salt", admin_salt)
	cfg.save(SETTINGS_PATH)
	var ac := ConfigFile.new()
	ac.set_value("accounts", "data", accounts)
	ac.save(ACCOUNTS_PATH)

func _hash_password(password: String, salt: String) -> String:
	var h := HashingContext.new()
	h.start(HashingContext.HASH_SHA256)
	h.update((salt + password).to_utf8_buffer())
	return h.finish().hex_encode()

func _clear() -> void:
	for c in get_children():
		c.queue_free()

func _label(text: String, size := 15, color := Color(0.92, 0.96, 1.0, 1.0)) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l

func _button(text: String, cb: Callable, primary := false) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 44)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.add_theme_font_size_override("font_size", 14)
	var s := StyleBoxFlat.new()
	s.bg_color = Color(0.08, 0.48, 0.43, 1) if primary else Color(0.12, 0.18, 0.27, 1)
	s.set_corner_radius_all(10)
	s.content_margin_left = 7
	s.content_margin_right = 7
	b.add_theme_stylebox_override("normal", s)
	var hov: StyleBoxFlat = s.duplicate()
	hov.bg_color = Color(0.10, 0.62, 0.54, 1) if primary else Color(0.18, 0.27, 0.39, 1)
	b.add_theme_stylebox_override("hover", hov)
	b.add_theme_stylebox_override("pressed", hov)
	b.pressed.connect(cb)
	return b

func _panel_style(p: PanelContainer) -> void:
	var s := StyleBoxFlat.new()
	s.bg_color = Color(0.07, 0.11, 0.17, 0.98)
	s.border_color = Color(0.20, 0.75, 0.66, 1)
	s.set_border_width_all(1)
	s.set_corner_radius_all(12)
	s.content_margin_left = 10
	s.content_margin_right = 10
	s.content_margin_top = 9
	s.content_margin_bottom = 9
	p.add_theme_stylebox_override("panel", s)

func _shell(title: String) -> VBoxContainer:
	_clear()
	var bg := ColorRect.new()
	bg.color = Color(0.035, 0.055, 0.09, 1)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 12)
	margin.add_theme_constant_override("margin_right", 12)
	margin.add_theme_constant_override("margin_top", 16)
	margin.add_theme_constant_override("margin_bottom", 10)
	add_child(margin)
	shell = VBoxContainer.new()
	shell.add_theme_constant_override("separation", 8)
	margin.add_child(shell)
	shell.add_child(_label(title, 24, Color(0.32, 0.92, 0.78, 1)))
	return shell

func _menu() -> void:
	var b := _shell("MEGA PROPERTY TYCOON 3D")
	b.add_child(_label("Bina empayar hartanah. Urus wang. Kalahkan 3 pesaing AI.", 14))
	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	b.add_child(spacer)
	var p := PanelContainer.new()
	_panel_style(p)
	b.add_child(p)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	p.add_child(v)
	v.add_child(_label("PERMAINAN OFFLINE", 18))
	v.add_child(_label("Prototaip boleh dimainkan • Autosave lokal", 12, Color(0.68,0.77,0.86,1)))
	v.add_child(_button("MULA PERMAINAN BAHARU", _new_game, true))
	v.add_child(_button("SAMBUNG PERMAINAN", _resume))
	v.add_child(_button("PROFIL / AKAUN", _account_screen))
	v.add_child(_button("TUKAR BAHASA", _toggle_language))
	v.add_child(_button("ADMIN PANEL", _admin_login))
	v.add_child(_button("CARA BERMAIN", _help))
	b.add_child(_label("Data disimpan pada peranti ini sahaja.", 11, Color(0.55,0.65,0.75,1)))

func _build_menu() -> void:
	_menu()

func _new_game() -> void:
	players = [
		{"name":active_username,"cash":START_CASH,"pos":0,"alive":true,"color":"#42e0bd","kind":"human","debt":0,"staff":0},
		{"name":"Investor AI","cash":START_CASH,"pos":0,"alive":true,"color":"#ffb347","kind":"investor","debt":0,"staff":0},
		{"name":"Business AI","cash":START_CASH,"pos":0,"alive":true,"color":"#8f8cff","kind":"business","debt":0,"staff":0},
		{"name":"Negotiator AI","cash":START_CASH,"pos":0,"alive":true,"color":"#ff6b8a","kind":"negotiator","debt":0,"staff":0}
	]
	properties.clear()
	for i in range(NAMES.size()):
		properties.append({"id":i,"name":NAMES[i],"type":TYPES[i],"price":PRICES[i],"rent":RENTS[i],"owner":-1,"level":0})
	current_player = 0
	current_tab = "board"
	match_started = true
	busy = false
	last_message = "Perlawanan bermula. Tekan LANCAR DADU."
	_save_game()
	_game_ui()

func _save_game() -> void:
	if not match_started or players.is_empty(): return
	var data := {"version":1,"players":players,"properties":properties,"current_player":current_player,"match_started":match_started,"active_username":active_username}
	var f := FileAccess.open(SAVE_PATH + ".tmp", FileAccess.WRITE)
	if f == null: return
	f.store_string(JSON.stringify(data))
	f.close()
	if FileAccess.file_exists(SAVE_PATH): DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
	DirAccess.rename_absolute(ProjectSettings.globalize_path(SAVE_PATH + ".tmp"), ProjectSettings.globalize_path(SAVE_PATH))

func _resume() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		_notice("Tiada save", "Mulakan permainan baharu dahulu.")
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		_notice("Ralat", "Fail save tidak dapat dibuka.")
		return
	var data = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(data) != TYPE_DICTIONARY or not data.has("players") or not data.has("properties"):
		_notice("Save rosak", "Simpanan tidak sah. Mulakan permainan baharu.")
		return
	players = data["players"]
	properties = data["properties"]
	current_player = int(data.get("current_player", 0))
	match_started = bool(data.get("match_started", true))
	active_username = str(data.get("active_username", active_username))
	last_message = "Perlawanan disambung."
	_game_ui()

func _game_ui() -> void:
	var b := _shell("MEGA PROPERTY TYCOON 3D")
	var row := HBoxContainer.new()
	b.add_child(row)
	cash_label = _label("", 16)
	cash_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(cash_label)
	turn_label = _label("", 13, Color(0.32,0.92,0.78,1))
	turn_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	row.add_child(turn_label)
	var tabs := HBoxContainer.new()
	b.add_child(tabs)
	tabs.add_child(_button("PAPAN", func(): _set_tab("board")))
	tabs.add_child(_button("BISNES", func(): _set_tab("business")))
	tabs.add_child(_button("KEWANGAN", func(): _set_tab("finance")))
	tabs.add_child(_button("MENU", _menu))
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.add_child(scroll)
	content = VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 8)
	scroll.add_child(content)
	var msg := PanelContainer.new()
	_panel_style(msg)
	content.add_child(msg)
	msg.add_child(_label(last_message, 13))
	if current_tab == "board": _board_tab()
	elif current_tab == "business": _business_tab()
	else: _finance_tab()
	var actions := HBoxContainer.new()
	b.add_child(actions)
	actions.add_child(_button("LANCAR DADU", _roll, true))
	actions.add_child(_button("TAMAT GILIRAN", _end_turn))
	_update_header()

func _set_tab(tab: String) -> void:
	current_tab = tab
	_game_ui()

func _board_tab() -> void:
	content.add_child(_label("PAPAN BANDAR", 17))
	content.add_child(_label("Tekan petak untuk melihat atau membeli hartanah. Harga dalam dolar permainan.", 11, Color(0.68,0.77,0.86,1)))
	var grid := GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 5)
	grid.add_theme_constant_override("v_separation", 5)
	content.add_child(grid)
	for i in range(properties.size()):
		var p: Dictionary = properties[i]
		var own := int(p["owner"])
		var suffix := ""
		if own >= 0: suffix = "\n" + str(players[own]["name"])
		var tile := _button(str(i+1)+". "+str(p["name"])+suffix, func(): _show_property(i))
		tile.custom_minimum_size = Vector2(0, 64)
		tile.add_theme_font_size_override("font_size", 10)
		var st := StyleBoxFlat.new()
		st.bg_color = _tile_color(str(p["type"]), own)
		st.set_corner_radius_all(7)
		st.content_margin_left = 3
		st.content_margin_right = 3
		tile.add_theme_stylebox_override("normal", st)
		tile.add_theme_stylebox_override("hover", st)
		grid.add_child(tile)
	content.add_child(_label("STATUS PEMAIN", 16))
	for i in range(players.size()):
		var pl: Dictionary = players[i]
		content.add_child(_label("%s • $%d • Petak %d • %d hartanah • %s" % [pl["name"],pl["cash"],int(pl["pos"])+1,_owned_count(i),"Aktif" if pl["alive"] else "BANKRAP"], 12))

func _tile_color(kind: String, owner: int) -> Color:
	if owner >= 0: return Color.from_string(str(players[owner]["color"]), Color(0.2,0.2,0.2)).darkened(0.42)
	match kind:
		"property": return Color(0.12,0.29,0.34,1)
		"utility": return Color(0.22,0.25,0.40,1)
		"chance": return Color(0.43,0.30,0.14,1)
		"community": return Color(0.23,0.33,0.24,1)
		"tax": return Color(0.42,0.18,0.22,1)
		"jail": return Color(0.32,0.20,0.34,1)
		_: return Color(0.13,0.20,0.28,1)

func _business_tab() -> void:
	content.add_child(_label("PENGURUSAN BISNES", 17))
	content.add_child(_label("Pekerja dan pembangunan ialah sistem asas prototaip. Pengurusan dikawal pemain.", 12))
	content.add_child(_button("AMBIL PEKERJA ($180)", _hire, true))
	content.add_child(_button("BANGUNKAN HARTANAH SENDIRI ($250)", _upgrade))
	content.add_child(_button("JUAL HARTANAH KEPADA BANK", _sell))
	content.add_child(_label("Hartanah milik awak:", 14))
	for p in properties:
		if int(p["owner"]) == 0:
			content.add_child(_label("%s • Tahap %d • Sewa $%d" % [p["name"],p["level"],_rent(p)], 12))

func _finance_tab() -> void:
	content.add_child(_label("DASHBOARD KEWANGAN", 17))
	content.add_child(_label("Tunai: $%d" % int(players[0]["cash"]), 16))
	content.add_child(_label("Hutang: $%d" % int(players[0]["debt"]), 14))
	content.add_child(_label("Hartanah: %d • Nilai anggaran: $%d" % [_owned_count(0),_portfolio_value(0)], 14))
	content.add_child(_button("PINJAMAN $500 (HUTANG $600)", _loan, true))
	content.add_child(_button("BAYAR HUTANG $300", _repay))
	content.add_child(_label("Kadar prototaip: pinjam $500 dan bayar balik $600. Tiada perkhidmatan bank online.", 11, Color(0.68,0.77,0.86,1)))

func _update_header() -> void:
	if players.is_empty(): return
	cash_label.text = "$%d" % int(players[0]["cash"])
	turn_label.text = "Giliran: " + str(players[current_player]["name"])

func _show_property(i: int) -> void:
	if busy: return
	var p: Dictionary = properties[i]
	var owner := int(p["owner"])
	var text := "%s\nKategori: %s\nHarga: $%d\nSewa asas: $%d\nTahap: %d" % [p["name"],p["type"],p["price"],p["rent"],p["level"]]
	if owner >= 0:
		_notice("Butiran Hartanah", text+"\nPemilik: "+str(players[owner]["name"])+"\nSewa semasa: $"+str(_rent(p)))
	elif int(p["price"]) > 0:
		var d := ConfirmationDialog.new()
		d.title = "Beli Hartanah?"
		d.dialog_text = text+"\nBeli hartanah ini?"
		add_child(d)
		d.confirmed.connect(func(): _buy(i))
		d.popup_centered()
	else: _notice("Butiran Petak", text)

func _buy(i: int) -> void:
	if current_player != 0 or busy: return
	var p: Dictionary = properties[i]
	if int(p["owner"]) != -1 or int(p["price"]) <= 0:
		_notice("Tidak tersedia", "Petak ini tidak boleh dibeli.")
		return
	if int(players[0]["cash"]) < int(p["price"]):
		_notice("Tunai tidak cukup", "Awak perlukan $%d." % int(p["price"]))
		return
	_change_cash(0, -int(p["price"]))
	p["owner"] = 0
	properties[i] = p
	last_message = "Awak membeli %s dengan harga $%d." % [p["name"],p["price"]]
	_after_action()

func _rent(p: Dictionary) -> int:
	return int(p["rent"]) * (1 + int(p["level"]))

func _roll() -> void:
	if busy or not match_started: return
	if current_player != 0:
		_notice("Giliran AI", "Tunggu giliran awak.")
		return
	busy = true
	var dice := randi_range(1,6) + randi_range(1,6)
	var old := int(players[0]["pos"])
	var pos := (old + dice) % properties.size()
	if pos < old: _change_cash(0,200)
	players[0]["pos"] = pos
	last_message = "Dadu %d. Awak bergerak ke %s." % [dice,properties[pos]["name"]]
	_resolve(0,pos)
	busy = false
	_save_game()
	_game_ui()

func _resolve(who: int, pos: int) -> void:
	var p: Dictionary = properties[pos]
	match str(p["type"]):
		"tax":
			_change_cash(who,-100); last_message += " Cukai bandar $100."
		"chance":
			var chance_amount := [100,-80,150,-50][randi_range(0,3)]; _change_cash(who,chance_amount); last_message += " Kad peluang: "+("terima" if chance_amount>=0 else "bayar")+" $"+str(abs(chance_amount))+"."
		"community":
			var community_amount := [120,-60,80,-40][randi_range(0,3)]; _change_cash(who,community_amount); last_message += " Kad komuniti: "+("terima" if community_amount>=0 else "bayar")+" $"+str(abs(community_amount))+"."
		"bank":
			_change_cash(who,100); last_message += " Bonus bank $100."
		"jail": last_message += " Singgah di penjara; tiada denda dalam prototaip."
		"property", "utility":
			var owner := int(p["owner"])
			if owner >= 0 and owner != who and bool(players[owner]["alive"]):
				var r := _rent(p); _change_cash(who,-r); _change_cash(owner,r)
				last_message += " Sewa $%d dibayar kepada %s." % [r,players[owner]["name"]]
			elif owner == -1 and who > 0:
				var price := int(p["price"])
				if int(players[who]["cash"]) >= price+250 and randf() < 0.68:
					_change_cash(who,-price); p["owner"] = who; properties[pos] = p
					last_message += " %s membeli %s." % [players[who]["name"],p["name"]]
	if int(players[who]["cash"]) < 0: _bankrupt(who)

func _change_cash(who: int, amount: int) -> void:
	players[who]["cash"] = int(players[who]["cash"]) + amount

func _bankrupt(who: int) -> void:
	if int(players[who]["cash"]) >= 0: return
	for p in properties:
		if int(p["owner"]) == who:
			p["owner"] = -1; p["level"] = 0
	players[who]["alive"] = false
	players[who]["cash"] = 0
	last_message += " %s bankrap; aset kembali kepada bank." % players[who]["name"]
	var alive_ai := 0
	for i in range(1,players.size()):
		if bool(players[i]["alive"]): alive_ai += 1
	if not bool(players[0]["alive"]): match_started = false; last_message += " Awak kalah."
	elif alive_ai == 0: match_started = false; last_message += " Awak menang!"

func _end_turn() -> void:
	if busy or current_player != 0 or not match_started: return
	busy = true
	for ai in range(1,players.size()):
		if not bool(players[ai]["alive"]): continue
		current_player = ai
		_game_ui()
		await get_tree().create_timer(0.35).timeout
		var dice := randi_range(1,6)+randi_range(1,6)
		var old := int(players[ai]["pos"])
		var pos := (old+dice)%properties.size()
		if pos < old: _change_cash(ai,200)
		players[ai]["pos"] = pos
		last_message = "%s melancarkan dadu (%d)." % [players[ai]["name"],dice]
		_resolve(ai,pos)
		_save_game()
		if not match_started: break
	current_player = 0
	busy = false
	_save_game()
	_game_ui()

func _owned_count(who: int) -> int:
	var n := 0
	for p in properties:
		if int(p["owner"]) == who: n += 1
	return n

func _portfolio_value(who: int) -> int:
	var n := 0
	for p in properties:
		if int(p["owner"]) == who: n += int(p["price"])+int(p["level"])*250
	return n

func _hire() -> void:
	if int(players[0]["cash"]) < 180: _notice("Tunai tidak cukup","Pengambilan pekerja memerlukan $180."); return
	_change_cash(0,-180); players[0]["staff"] = int(players[0].get("staff",0))+1
	last_message = "Pekerja diambil. Jumlah pekerja: %d." % int(players[0]["staff"]); _after_action()

func _upgrade() -> void:
	var owned: Array = []
	for i in range(properties.size()):
		if int(properties[i]["owner"]) == 0: owned.append(i)
	if owned.is_empty(): _notice("Tiada hartanah","Beli hartanah dahulu."); return
	var opts := OptionButton.new()
	for i in owned: opts.add_item(str(properties[i]["name"])+" • Tahap "+str(properties[i]["level"]))
	var d := ConfirmationDialog.new(); d.title = "Pembangunan ($250)"; d.add_child(opts); add_child(d)
	d.confirmed.connect(func():
		if int(players[0]["cash"]) < 250: _notice("Tunai tidak cukup","Perlu $250."); return
		var idx: int = owned[opts.selected]; _change_cash(0,-250); properties[idx]["level"] = int(properties[idx]["level"])+1
		last_message = "Pembangunan %s siap. Sewa meningkat." % properties[idx]["name"]; _after_action()
	)
	d.popup_centered()

func _sell() -> void:
	var owned: Array = []
	for i in range(properties.size()):
		if int(properties[i]["owner"]) == 0: owned.append(i)
	if owned.is_empty(): _notice("Tiada hartanah","Awak belum memiliki hartanah."); return
	var opts := OptionButton.new()
	for i in owned: opts.add_item(str(properties[i]["name"])+" • $"+str(int(properties[i]["price"])/2))
	var d := ConfirmationDialog.new(); d.title = "Jual kepada bank"; d.add_child(opts); add_child(d)
	d.confirmed.connect(func():
		var idx: int = owned[opts.selected]; var value: int = int(int(properties[idx]["price"])/2)
		_change_cash(0,value); properties[idx]["owner"] = -1; properties[idx]["level"] = 0
		last_message = "Hartanah dijual kepada bank dengan harga $%d." % value; _after_action()
	)
	d.popup_centered()

func _loan() -> void:
	if int(players[0]["debt"]) > 0: _notice("Pinjaman sedia ada","Selesaikan hutang semasa dahulu."); return
	_change_cash(0,500); players[0]["debt"] = 600; last_message = "Pinjaman $500 diterima; hutang $600."; _after_action()

func _repay() -> void:
	var debt := int(players[0]["debt"])
	if debt <= 0: _notice("Tiada hutang","Awak tiada hutang."); return
	var amount := min(300,debt)
	if int(players[0]["cash"]) < amount: _notice("Tunai tidak cukup","Tunai tidak mencukupi."); return
	_change_cash(0,-amount); players[0]["debt"] = debt-amount
	last_message = "Bayar hutang $%d. Baki hutang $%d." % [amount,players[0]["debt"]]; _after_action()

func _after_action() -> void:
	_save_game(); _game_ui()

func _account_screen() -> void:
	var b := _shell("PROFIL / AKAUN TEMPATAN")
	b.add_child(_label("Akaun disimpan pada peranti sahaja. Jangan guna kata laluan penting yang sama.",12))
	var user := LineEdit.new(); user.placeholder_text = "Nama pengguna"; b.add_child(user)
	var pass := LineEdit.new(); pass.placeholder_text = "Kata laluan (minimum 6 aksara)"; pass.secret = true; b.add_child(pass)
	var row := HBoxContainer.new(); b.add_child(row)
	row.add_child(_button("DAFTAR", func(): _register(user.text.strip_edges(),pass.text), true))
	row.add_child(_button("LOG MASUK", func(): _login(user.text.strip_edges(),pass.text)))
	b.add_child(_button("KEMBALI", _menu))
	b.add_child(_label("Profil aktif: "+active_username,13,Color(0.32,0.92,0.78,1)))

func _register(user: String, password: String) -> void:
	if user.length() < 3 or password.length() < 6: _notice("Maklumat tidak sah","Username minimum 3 aksara dan kata laluan minimum 6 aksara."); return
	if accounts.has(user.to_lower()): _notice("Nama digunakan","Pilih username lain."); return
	var salt := str(randi())+str(Time.get_ticks_msec())
	accounts[user.to_lower()] = {"name":user,"salt":salt,"hash":_hash_password(password,salt)}
	active_username = user; _save_local(); _notice("Akaun dibuat","Akaun lokal berjaya dibuat."); _menu()

func _login(user: String, password: String) -> void:
	var key := user.to_lower()
	if not accounts.has(key): _notice("Log masuk gagal","Akaun tidak dijumpai."); return
	var data: Dictionary = accounts[key]
	if _hash_password(password,str(data["salt"])) != str(data["hash"]): _notice("Log masuk gagal","Username atau kata laluan salah."); return
	active_username = str(data["name"]); _save_local(); _notice("Berjaya","Selamat kembali, "+active_username+"."); _menu()

func _toggle_language() -> void:
	language = "en" if language == "ms" else "ms"; _save_local()
	_notice("Language","Pilihan disimpan; kebanyakan teks prototaip masih dalam Bahasa Melayu.")
	_menu()

func _admin_login() -> void:
	var b := _shell("ADMIN PANEL • OFFLINE")
	b.add_child(_label("Admin email: "+ADMIN_EMAIL,12))
	b.add_child(_label("Tetapkan kata laluan sendiri pada penggunaan pertama. E-mel sahaja bukan pengesahan.",12,Color(0.68,0.77,0.86,1)))
	var email := LineEdit.new(); email.placeholder_text = "E-mel admin"; email.text = ADMIN_EMAIL; b.add_child(email)
	var pass := LineEdit.new(); pass.placeholder_text = "Kata laluan admin (minimum 8)"; pass.secret = true; b.add_child(pass)
	b.add_child(_button("LOG MASUK / SETUP", func(): _admin_auth(email.text.strip_edges(),pass.text), true))
	b.add_child(_button("KEMBALI", _menu))

func _admin_auth(email: String, password: String) -> void:
	if email.to_lower() != ADMIN_EMAIL or password.length() < 8: _notice("Akses ditolak","Gunakan e-mel admin dan kata laluan minimum 8 aksara."); return
	if admin_hash.is_empty():
		admin_salt = str(randi())+str(Time.get_ticks_msec()); admin_hash = _hash_password(password,admin_salt); _save_local()
		_notice("Admin disediakan","Kata laluan admin telah disimpan secara hash. Log masuk sekali lagi untuk membuka panel."); return
	if _hash_password(password,admin_salt) != admin_hash: _notice("Akses ditolak","Kata laluan salah."); return
	_admin_panel()

func _admin_panel() -> void:
	var b := _shell("ADMIN PANEL")
	b.add_child(_label("Admin ini hanya berfungsi pada peranti semasa. Tiada kawalan jauh.",12))
	b.add_child(_button("DIAGNOSTIK SAVE", func(): _notice("Diagnostik","Perlawanan aktif: %s\nPemain: %d\nHartanah: %d" % [str(match_started),players.size(),properties.size()])))
	b.add_child(_button("RESET SAVE PERLAWANAN", _reset_match))
	b.add_child(_button("TUTUP PANEL", _menu))

func _reset_match() -> void:
	var d := ConfirmationDialog.new(); d.title = "Reset perlawanan"; d.dialog_text = "Padam save perlawanan lokal? Tindakan ini tidak boleh dibuat asal."; add_child(d)
	d.confirmed.connect(func():
		if FileAccess.file_exists(SAVE_PATH): DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
		match_started = false; players.clear(); properties.clear(); _admin_panel()
	)
	d.popup_centered()

func _help() -> void:
	_notice("Cara bermain","1. Mula permainan.\n2. Lancar dadu.\n3. Tekan petak hartanah untuk melihat atau membeli.\n4. Tab Bisnes: ambil pekerja, bangunkan atau jual hartanah.\n5. Tab Kewangan: pinjaman dan bayaran hutang.\n6. Tamat giliran untuk menjalankan AI.\n7. Autosave dibuat pada peranti.")

func _notice(title: String, body: String) -> void:
	var d := AcceptDialog.new(); d.title = title; d.dialog_text = body; add_child(d)
	d.confirmed.connect(func(): d.queue_free())
	d.canceled.connect(func(): d.queue_free())
	d.popup_centered(Vector2i(370,240))
