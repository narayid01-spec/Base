# VEdit Pro — projek Android

Ini ialah **projek sumber Android**, bukan fail APK yang telah dikompilasi. Projek ini menyediakan versi awal aplikasi dengan:
- Pilih video menggunakan pemilih fail Android
- Pratonton video
- Tetapkan masa mula dan akhir
- Eksport trim ke MP4 melalui AndroidX Media3 Transformer
- GitHub Actions untuk membina APK debug secara automatik

## Cara mendapatkan APK menggunakan telefon Android

1. Ekstrak `VEditPro-Android.zip`.
2. Buka https://github.com dan log masuk atau cipta akaun percuma.
3. Cipta repository baharu bernama `VEditPro`, pilih Public atau Private.
4. Muat naik semua fail projek dan folder termasuk `.github/workflows/android.yml`, `app/`, `settings.gradle.kts`, `build.gradle.kts` dan `gradle.properties`.
5. Pastikan workflow berada tepat pada `.github/workflows/android.yml`.
6. Buka tab **Actions** pada repository. Jika diminta, aktifkan Actions.
7. Pilih **Build VEdit Pro APK** kemudian tekan **Run workflow**, atau buat push ke branch `main`.
8. Tunggu sehingga binaan selesai. Jika hijau, buka run tersebut dan muat turun artifact `VEditPro-debug-apk`.
9. Ekstrak ZIP artifact dan pasang `app-debug.apk` pada telefon. Android mungkin meminta anda membenarkan pemasangan daripada sumber tersebut.

## Jika binaan gagal

Buka run dalam GitHub Actions dan baca bahagian log yang merah. Versi Android Gradle Plugin, Kotlin, Media3 dan Compose boleh berubah; pembaikan mungkin diperlukan jika dependency atau API tidak serasi. Hantar log ralat untuk dibantu.

## Had versi pertama

Versi ini belum mempunyai teks overlay, muzik latar, filter visual, berbilang klip, timeline drag-and-drop atau undo/redo. Ia fokus pada import, preview, trim dan eksport. Uji pada peranti sebenar kerana keserasian codec bergantung pada fail dan peranti.
