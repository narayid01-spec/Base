package com.veditpro.app

import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF101018)
private val Panel = Color(0xFF1B1B28)
private val Accent = Color(0xFF9B72FF)
private val TextMain = Color(0xFFF4F1FF)

class MainActivity : ComponentActivity() {
    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VEditApp() }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun VEditApp() {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var startSeconds by remember { mutableStateOf("0") }
    var endSeconds by remember { mutableStateOf("10") }
    var exporting by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Pilih video untuk mula menyunting.") }
    var player by remember { mutableStateOf<ExoPlayer?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            videoUri = uri
            status = "Video dipilih. Tetapkan masa mula dan akhir, kemudian eksport."
        }
    }

    DisposableEffect(videoUri) {
        val uri = videoUri
        if (uri != null) {
            val newPlayer = ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(uri))
                prepare()
                playWhenReady = false
            }
            player = newPlayer
        } else player = null
        onDispose { player?.release(); player = null }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, background = Bg, surface = Panel,
        onBackground = TextMain, onSurface = TextMain
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(Bg)
                .verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Movie, contentDescription = null, tint = Accent, modifier = Modifier.size(34.dp))
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("VEdit Pro", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = TextMain)
                    Text("Editor video Android", color = Color.LightGray, fontSize = 13.sp)
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("PRATONTON VIDEO", fontWeight = FontWeight.Bold, color = Accent)
                    if (player != null) {
                        AndroidView(
                            factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
                            update = { it.player = player },
                            modifier = Modifier.fillMaxWidth().height(220.dp)
                        )
                    } else {
                        Box(Modifier.fillMaxWidth().height(180.dp).background(Color(0xFF292638), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = Accent, modifier = Modifier.size(42.dp))
                                Spacer(Modifier.height(8.dp))
                                Text("Belum ada video dipilih", color = TextMain)
                            }
                        }
                    }
                    Button(onClick = { picker.launch("video/*") }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.VideoLibrary, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Pilih video daripada telefon")
                    }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ContentCut, contentDescription = null, tint = Accent)
                        Spacer(Modifier.width(8.dp))
                        Text("Potong video (Trim)", fontWeight = FontWeight.Bold, color = TextMain)
                    }
                    Text("Masukkan masa dalam saat. Contoh: mula 2, akhir 12.", color = Color.LightGray, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = startSeconds, onValueChange = { startSeconds = it.filter(Char::isDigit).take(6) },
                            label = { Text("Mula (saat)") }, modifier = Modifier.weight(1f), singleLine = true
                        )
                        OutlinedTextField(
                            value = endSeconds, onValueChange = { endSeconds = it.filter(Char::isDigit).take(6) },
                            label = { Text("Akhir (saat)") }, modifier = Modifier.weight(1f), singleLine = true
                        )
                    }
                    Button(
                        onClick = {
                            val uri = videoUri
                            val start = startSeconds.toLongOrNull()
                            val end = endSeconds.toLongOrNull()
                            if (uri == null) {
                                status = "Sila pilih video dahulu."
                            } else if (start == null || end == null || end <= start) {
                                status = "Masa tidak sah. Masa akhir mesti lebih besar daripada masa mula."
                            } else {
                                exportTrimmedVideo(context, uri, start * 1000, end * 1000,
                                    onStart = { exporting = true; status = "Mengeksport video…" },
                                    onDone = { output -> exporting = false; status = "Berjaya! Video disimpan: $output" },
                                    onError = { error -> exporting = false; status = "Eksport gagal: $error" })
                            }
                        },
                        enabled = !exporting,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (exporting) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                            Spacer(Modifier.width(8.dp))
                            Text("Sedang mengeksport…")
                        } else {
                            Icon(Icons.Default.FileDownload, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Eksport MP4")
                        }
                    }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("STATUS", color = Accent, fontWeight = FontWeight.Bold)
                    Text(status, color = TextMain)
                    Text("Versi 1.0 • Tiada akaun atau langganan diperlukan", color = Color.LightGray, fontSize = 12.sp)
                }
            }
            Text("Nota: Versi pertama ini memfokuskan pemilihan, pratonton, trim dan eksport. Ciri teks, muzik, filter dan berbilang klip belum disertakan.", color = Color.LightGray, fontSize = 12.sp)
        }
    }
}

@OptIn(UnstableApi::class)
private fun exportTrimmedVideo(
    context: android.content.Context,
    inputUri: Uri,
    startMs: Long,
    endMs: Long,
    onStart: () -> Unit,
    onDone: (String) -> Unit,
    onError: (String) -> Unit
) {
    try {
        val outputDir = File(context.cacheDir, "vedit_exports").apply { mkdirs() }
        val outputFile = File(outputDir, "vedit_${System.currentTimeMillis()}.mp4")
        val clipping = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(startMs)
            .setEndPositionMs(endMs)
            .build()
        val mediaItem = MediaItem.Builder().setUri(inputUri).setClippingConfiguration(clipping).build()
        val editedItem = EditedMediaItem.Builder(mediaItem).build()
        val transformer = Transformer.Builder(context)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    try {
                        val values = ContentValues().apply {
                            put(MediaStore.Video.Media.DISPLAY_NAME, outputFile.name)
                            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VEditPro")
                        }
                        val resolver = context.contentResolver
                        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        val outputUri = resolver.insert(collection, values)
                        if (outputUri != null) {
                            outputFile.inputStream().use { input -> resolver.openOutputStream(outputUri)?.use { output -> input.copyTo(output) } }
                            outputFile.delete()
                            onDone("Movies/VEditPro")
                        } else {
                            onDone(outputFile.absolutePath)
                        }
                    } catch (e: Exception) {
                        onError(e.message ?: "Tidak dapat menyimpan fail")
                    }
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    outputFile.delete()
                    onError(exportException.message ?: "Ralat pemprosesan video")
                }
            })
            .build()
        onStart()
        transformer.start(editedItem, outputFile.absolutePath)
    } catch (e: Exception) {
        onError(e.message ?: "Ralat tidak diketahui")
    }
}
