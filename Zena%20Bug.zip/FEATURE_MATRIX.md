# Zena V1.1 reconstructed feature matrix

**Status meanings**
- **Local implemented**: logic runs in the reconstructed app without needing the legacy Zena server.
- **External implemented**: app calls an identified public endpoint or opens a provider; provider availability can change.
- **Legacy API dependent**: the route name was identified in the compiled package, but the original server's exact contract and availability cannot be independently verified.
- **Admin API implemented**: backed by the included replacement Flask/SQLite API; it must be deployed and configured.
- **Limited / not recovered**: original behavior could not be recovered from compiled source and is explicitly not claimed as complete.

| Area | Feature | Current implementation | Status |
|---|---|---|---|
| Navigation | Home, feature search, grouped modules, settings | Responsive Flutter navigation and search | Local implemented |
| Account | Login, create account, profile | Calls legacy `/validate`, `/createAccount`, `/myInfo` | Legacy API dependent |
| Account | Recovery, change password | Safe unavailable message because legacy route/schema was not confirmed | Limited / not recovered |
| Account | Device sessions, revoke sessions | Calls `/getDeviceLogs`, `/revokeSessions` | Legacy API dependent |
| AI | AI Assistant | Sends question to `/ai/ask` | Legacy API dependent; provider setup unknown |
| Social | Global chat list and text send | `/getPublicChat`, `/sendPublicChat` | Legacy API dependent |
| Social | Global chat image upload | Gallery selection + multipart `/sendPublicImage` | Legacy API dependent; upload schema unknown |
| Social | Voice note | Records AAC audio locally and uploads `/sendPublicVoice` | Legacy API dependent; upload schema unknown |
| Social | Private chat list/send | Calls `/social/users`, `/getPrivateChat`, `/sendPrivateChat` | Legacy API dependent; routes inferred |
| Social | Profile search/follow/unfollow | Calls `/social/users`, `/social/follow`, `/social/following` | Legacy API dependent |
| Tools | DNS A/MX/NS | Google DNS-over-HTTPS | External implemented |
| Tools | Subdomains | crt.sh certificate-transparency search | External implemented; incomplete by nature |
| Tools | Public IP | ipify | External implemented |
| Tools | GPS location | Geolocator permission flow | Local implemented; requires device permission/GPS |
| Tools | QR generator | QR code rendered from user text/URL | Local implemented |
| Tools | Instagram downloader | Calls third-party downloader with validated Instagram URL | External implemented; provider may fail/change |
| Tools | TikTok downloader | Calls third-party downloader with validated TikTok URL | External implemented; provider may fail/change |
| Tools | Email OSINT | MX DNS lookup for email domain only | External implemented; does not identify account owner |
| Tools | Phone lookup | Format validation only | Local implemented; no private identity lookup |
| Tools | NIK checker | 16-digit format check only; identifier is not transmitted | Local implemented; no identity lookup |
| Network | Proxy guidance | Shows Android manual proxy steps | Local implemented; does not silently alter system proxy |
| Network | Wi-Fi tools | HTTPS connectivity check only | External implemented; no network disruption |
| System | Server manager | Calls `/myServer`, `/addServer`, `/delServer` | Legacy API dependent; payload schema inferred |
| Games | Galaxy Shooter | Offline tap-target arcade mini-game | Local implemented; reconstructed game, not original source |
| Games | Turbo Racer | Offline lane-avoidance mini-game | Local implemented; reconstructed game, not original source |
| Games | Dark Horror | Offline choose-safe-door mini-game | Local implemented; reconstructed game, not original source |
| Games | Chess Master | Offline chess knowledge quiz; not a full chess engine | Local implemented with limited gameplay |
| Games | IQ Master | Offline quiz and scoring | Local implemented |
| Games | Tug of War | Offline tap-to-pull game | Local implemented |
| Games | Ular Tangga | Offline dice/board game with snakes and ladders | Local implemented |
| Media | Hexagram stories list/upload | Calls `/hexagram/stories` and multipart upload | Legacy API dependent; schema unknown |
| Media | YouTube and music search | Opens YouTube search results | External implemented; no direct licensed music stream |
| Content | News RSS | Parses RSS items from Antara, Detik, Kompas | External implemented; feed URLs may change |
| Content | Weather | Open-Meteo geocoding + current weather | External implemented |
| Content | Prayer times | AlAdhan timings by city | External implemented |
| Content | NGL helper | Opens NGL website | External implemented |
| Account | Voucher redemption | Calls `/redeemVoucher` | Legacy API dependent |
| System | Script bot files/upload | Calls `/script-bot/files`, `/script-bot/upload` | Legacy API dependent; file policy/server required |
| System | Sender management | Calls sender routes exposed in the compiled app | Legacy API dependent; exact payloads unknown |
| System | Bug explanations | Calls `/getBugExplanations` | Legacy API dependent |
| Owner | Owner dashboard and control center | Calls identified Owner endpoints | Legacy API dependent |
| Owner | User/device/content management | Calls identified legacy Owner endpoints | Legacy API dependent |
| Owner | Update center/changelog/status/bootstrap | Calls `/app/changelog`, `/app/status`, `/app/bootstrap` | Legacy API dependent |
| Owner | Polls/events/vouchers/AI settings/knowledge | Calls identified legacy Owner endpoints | Legacy API dependent |
| Admin | Admin login and initial password rotation | Flask bearer token, password hash, first-login password change | Admin API implemented |
| Admin | User list/create/ban/unban/delete/role | Flask + SQLite + role checks | Admin API implemented |
| Admin | Voucher create/list/status/delete | Flask + SQLite | Admin API implemented |
| Admin | Stats and audit logs | Flask + SQLite | Admin API implemented |
| Admin | Content and announcements | Flask + SQLite | Admin API implemented |
| Admin | Notifications | Flask + SQLite | Admin API implemented; storage only, not push delivery |
| Admin | Events | Flask + SQLite | Admin API implemented |
| Admin | Poll creation/list/voting | Flask + SQLite | Admin API implemented; no public voting UI included |
| Admin | AI knowledge records | Flask + SQLite | Admin API implemented; not automatically connected to an AI provider |
| Admin | Feature flags | Flask + SQLite | Admin API implemented; flags do not remotely disable Flutter UI yet |
| Admin | Settings | Flask + SQLite | Admin API implemented |
| Admin | Backup and restore | SQLite backup API and restore endpoint | Admin API implemented; use persistent storage in deployment |
| Build | GitHub Actions release APK | Generates Android project files, runs tests, builds `Zena Bug.apk` | CI configured; actual CI run still required |

## Not recovered from the APK

- Original Dart source, original widget tree and original game code.
- Original backend source/database/credentials and exact payload contracts.
- Guarantee that every third-party API or legacy endpoint is live.
- Original downloader, sender, bug-management, anti-abuse, or remote device-control implementation.
- Physical Android device verification. CI build is needed to verify compilation, and live-service/device tests are needed to verify integrations.
