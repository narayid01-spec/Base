# Zena V1.1 — Reconstructed Source Package

This package is a complete, self-contained **reconstruction project** for the Zena V1.1 modules that could be identified from the supplied compiled Android package. It is not the original Flutter source and is not a byte-for-byte rebuild of the original APK.

## Included in this ZIP

- Flutter Android app source, responsive mobile UI, search and grouped feature navigation.
- Original image, video, audio, and font assets extracted from the supplied package.
- Feature screens for account/API integration, AI, public/private social entry points, domain/DNS/subdomain tools, IP/GPS, QR, external media links, news RSS, weather, prayer times, vouchers, scripts/senders, server status, and Owner tools.
- Offline mini-games for Galaxy Shooter, Turbo Racer, Dark Horror, Chess Master quiz, Tug of War, IQ Master quiz, and Ular Tangga.
- Admin-only login gate (only SUPER_ADMIN/ADMIN roles are admitted), complete reconstructed feature dashboard, and Flask/SQLite backend with user management, voucher management, audit logs, settings, content, notifications, events, polls, AI knowledge, feature flags, backup/restore, and bug-report submission/assignment/status tracking.
- Backend regression tests and Flutter widget smoke test.
- GitHub Actions workflow that generates Android project files, tests the Admin API, runs Flutter tests, and builds `Zena Bug.apk`.
- Render deployment blueprint for the replacement Admin API.

## Important boundary: original source and backend

The supplied Zena package is a **compiled Flutter Android app**. It contains compiled Dart AOT code (`libapp.so`) and DEX files, not the original Flutter project (`lib/*.dart`, original `pubspec.yaml`, and original `android/` folder). Therefore, the app in this repository is reconstructed from observed feature names, endpoint references, and extracted assets. The seven mini-games are new offline implementations, not recovered original game source.

The included replacement Admin API seeds the initial account from `ZENA_ADMIN_USERNAME` / `ZENA_ADMIN_PASSWORD` (defaults: `adamhdhbbb` / `Adam7875`). Set strong environment secrets before public deployment. The original legacy server's private implementation, API credentials, database, and exact request/response contracts were not included. Features that call the legacy Zena API will only work when that server is reachable and accepts the request format used here. Third-party providers can change or rate-limit their APIs. No project can honestly guarantee every original feature is operational without access to those services and runtime testing.

## Build Android APK with GitHub Actions

1. Extract this ZIP.
2. Upload the **contents** of the extracted folder to the root of a GitHub repository. Keep the hidden `.github` directory.
3. Open **Actions → Build Zena Bug APK → Run workflow**.
4. When both backend tests and Flutter tests pass, download the artifact named **Zena Bug APK**. The APK inside is named `Zena Bug.apk`.

Recommended GitHub repository variables: Settings → Secrets and variables → Actions → Variables.

- `ZENA_API_BASE`: HTTPS URL of a compatible legacy Zena API. If blank, the app uses the legacy URL found in the supplied package (HTTP; compatibility/testing only).
- `ZENA_ADMIN_API_BASE`: HTTPS URL where the replacement `server/` API is deployed. Do not leave the default `10.0.2.2` address for a physical phone.

## Deploy the replacement Admin API

A Render blueprint is included in `render.yaml`. Set `ZENA_ADMIN_PASSWORD` as a deployment secret. The first account is `adam`; if no password is supplied in a local development environment, the temporary development password is `7875811`. The backend requires that initial password to be changed to a password of at least 10 characters before using Admin endpoints. Do not publish the API with the default password.

The Render blueprint uses persistent storage for the SQLite database and backups. Verify the deployment's assigned HTTPS URL, then set that URL as `ZENA_ADMIN_API_BASE` in GitHub repository variables and rebuild the APK.

For local development:

```bash
cd server
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
export ZENA_ADMIN_USERNAME=adam
export ZENA_ADMIN_PASSWORD='set-a-strong-initial-password'
python app.py
```

PowerShell example:

```powershell
$env:ZENA_ADMIN_USERNAME="adam"
$env:ZENA_ADMIN_PASSWORD="set-a-strong-initial-password"
python app.py
```

## Verification status

- Python syntax checks: run locally when packaging.
- Admin API regression tests: included; GitHub Actions runs them with dependencies installed.
- Flutter widget smoke test: included; GitHub Actions runs it.
- Release APK build: delegated to GitHub Actions because Flutter SDK is not installed in this environment.
- Physical-device testing: not performed here.

A successful CI build verifies compilation and tests in the CI environment; it does not by itself verify that every external API, the legacy Zena server, GPS permission behavior, uploads, or production Admin deployment works on a real device.

## Security notes

- Never commit API keys, tokens, passwords, signing keystores, or `.env` files.
- The legacy endpoint identified in the original package uses HTTP. Migrate to HTTPS before production.
- Admin backend requires HTTPS in production and a persistent database volume.
- Phone lookup and NIK checker in this reconstruction perform format checks only; they do not transmit personal identifiers to unverified third-party services.
- Wi-Fi tools perform a connectivity check only. They do not attempt to disrupt networks or other devices.
