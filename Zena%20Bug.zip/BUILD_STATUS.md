# Build and integration status

This repository is the full source package for the reconstruction, not a patch.

## Verified locally in the preparation environment

- Python backend files pass `python -m py_compile`.
- Dart source files have balanced delimiters under a static source check.
- GitHub Actions and Render YAML parse as YAML.
- All declared Flutter asset directories exist and the bundled image/video/audio/font assets are present.
- Workflow is configured to run backend regression tests, a Flutter widget smoke test, and a release APK build in GitHub Actions.

## Not verifiable in this environment

- Flutter/Dart compilation: Flutter SDK is not installed here, so the actual APK build must be verified by GitHub Actions.
- Flask runtime tests: Flask dependencies cannot be downloaded in this environment; the tests are included for GitHub Actions to execute.
- Live legacy API calls: the original backend's source and exact payload schemas were not supplied.
- Production Admin login: the included Admin API must be deployed and `ZENA_ADMIN_API_BASE` set to its HTTPS URL.
- Physical-device microphone, GPS, gallery upload, and provider integrations: require an installed APK and runtime tests.

A build is only considered verified when GitHub Actions reports the backend tests, Flutter tests, and APK build all passing. External service features remain dependent on their providers and on the original legacy server where noted in `FEATURE_MATRIX.md`.
