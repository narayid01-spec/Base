import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  // Override at build time: --dart-define=ZENA_API_BASE=https://your-api.example
  static const String legacyBase = String.fromEnvironment(
    'ZENA_API_BASE',
    defaultValue: 'http://node.cloverznewera.my.id:2000',
  );
  static const String adminBase = String.fromEnvironment(
    'ZENA_ADMIN_API_BASE',
    defaultValue: 'http://10.0.2.2:5001',
  );

  static Future<String?> _token() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('zena_admin_token');
  }

  static Future<Map<String, String>> _headers({bool admin = false}) async {
    final headers = <String, String>{'Accept': 'application/json', 'Content-Type': 'application/json'};
    if (admin) {
      final token = await _token();
      if (token != null) headers['Authorization'] = 'Bearer $token';
    }
    return headers;
  }

  static Future<dynamic> getLegacy(String path, {Map<String, String>? query}) async {
    final uri = Uri.parse('$legacyBase$path').replace(queryParameters: query);
    final response = await http.get(uri, headers: await _headers()).timeout(const Duration(seconds: 20));
    return _decode(response);
  }

  static Future<dynamic> postLegacy(String path, Map<String, dynamic> body) async {
    final response = await http.post(Uri.parse('$legacyBase$path'), headers: await _headers(), body: jsonEncode(body)).timeout(const Duration(seconds: 20));
    return _decode(response);
  }

  static Future<dynamic> getAdmin(String path) async {
    final response = await http.get(Uri.parse('$adminBase$path'), headers: await _headers(admin: true)).timeout(const Duration(seconds: 20));
    return _decode(response);
  }

  static Future<dynamic> postAdmin(String path, Map<String, dynamic> body, {bool auth = true}) async {
    final response = await http.post(Uri.parse('$adminBase$path'), headers: await _headers(admin: auth), body: jsonEncode(body)).timeout(const Duration(seconds: 20));
    return _decode(response);
  }


  static Future<dynamic> uploadLegacy(String path, Uint8List bytes, String filename, {String fieldName = 'file'}) async {
    final uri = Uri.parse('$legacyBase$path');
    final request = http.MultipartRequest('POST', uri);
    request.headers['Accept'] = 'application/json';
    request.files.add(http.MultipartFile.fromBytes(fieldName, bytes, filename: filename));
    final streamed = await request.send().timeout(const Duration(seconds: 45));
    final response = await http.Response.fromStream(streamed);
    return _decode(response);
  }

  static dynamic _decode(http.Response response) {
    dynamic body;
    try { body = jsonDecode(response.body); } catch (_) { body = response.body; }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('HTTP ${response.statusCode}: ${body is Map ? body['error'] ?? body : body}');
    }
    return body;
  }
}
