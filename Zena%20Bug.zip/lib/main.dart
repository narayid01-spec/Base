import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:record/record.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:xml/xml.dart';
import 'services/api_service.dart';
import 'screens/admin_screen.dart';
import 'screens/games_screen.dart';

void main() => runApp(const ZenaApp());

const purple = Color(0xFF9B87F5);
const bg = Color(0xFF0B0B12);

class ZenaApp extends StatelessWidget {
  const ZenaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Zena V1.1', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, brightness: Brightness.dark, scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: purple, brightness: Brightness.dark),
      fontFamily: 'Rajdhani'),
    home: const HomeScreen(),
  );
}

class Feature {
  final String name, category, description, icon, endpoint;
  final List<String> actions;
  const Feature(this.name, this.category, this.description, this.icon, this.endpoint, this.actions);
}

const features = <Feature>[
 Feature('Login & Account','Account','Login dan pengesahan akaun melalui backend.','◎','/validate',['Login']),
 Feature('Create Account','Account','Penciptaan akaun pengguna.','＋','/createAccount',['Cipta akaun']),
 Feature('Account Recovery','Account','Pemulihan akses akaun.','↺','',['Pulihkan akaun']),
 Feature('Change Password','Account','Tukar kata laluan akaun.','🔑','',['Tukar kata laluan']),
 Feature('My Profile','Account','Maklumat akaun semasa.','◉','/myInfo',['Muat profil']),
 Feature('Device Sessions','Account','Lihat log peranti dan sesi berkaitan.','▣','/getDeviceLogs',['Muat log peranti','Tarik balik sesi']),
 Feature('AI Assistant','AI & Media','Tanya AI melalui backend Zena.','✦','/ai/ask',['Tanya AI','AI Knowledge','Tetapan AI']),
 Feature('Chat Global','Social','Mesej awam, imej dan voice note.','◉','/getPublicChat',['Muat mesej','Hantar mesej','Hantar imej','Hantar voice note']),
 Feature('Chat Peribadi','Social','Komunikasi antara pengguna.','✉','/social/users',['Cari pengguna','Senarai pengguna','Muat chat (username)','Hantar mesej (username|mesej)']),
 Feature('Profil & Follow','Social','Profil awam dan hubungan sosial.','◎','/social/users',['Cari pengguna','Senarai following','Follow pengguna','Unfollow pengguna']),
 Feature('Domain OSINT','Tools','Semakan domain dan DNS.','⌕','/api/tools/dns',['Semak DNS','Semak subdomain']),
 Feature('IP & GPS','Tools','Maklumat IP dan lokasi dengan kebenaran.','⌖','/api/tools/dns',['Semak IP awam','Dapatkan GPS']),
 Feature('QR Generator','Tools','Jana QR daripada teks atau URL.','▦','', ['Jana QR']),
 Feature('Instagram Downloader','Tools','Hantar pautan Instagram kepada servis downloader.','▶','', ['Proses pautan']),
 Feature('TikTok Downloader','Tools','Semak pautan video awam.','▷','', ['Proses pautan']),
 Feature('Email OSINT','Tools','Semakan melalui perkhidmatan luar.','@','/api/tools/nik-checker',['Semak data']),
 Feature('Phone Lookup','Tools','Carian melalui servis yang disediakan.','☎','',['Semak nombor']),
 Feature('NIK Checker','Tools','Semakan melalui API luaran jika tersedia.','▤','/api/tools/nik-checker',['Semak NIK']),
 Feature('Proxy Settings','Network','Paparan bantuan konfigurasi proxy.','⇄','',['Panduan proxy']),
 Feature('WiFi Tools','Network','Alat diagnostik rangkaian yang dibenarkan.','⌁','',['Semak status rangkaian']),
 Feature('Server Manager','System','Pengurusan server melalui backend lama.','▣','/myServer',['Senarai server','Tambah server','Padam server']),
 Feature('Galaxy Shooter','Games','Permainan arcade angkasa.','✧','/games/profile',['Profil permainan','Kemajuan']),
 Feature('Turbo Racer','Games','Permainan perlumbaan arcade.','◈','/games/profile',['Profil permainan','Kemajuan']),
 Feature('Dark Horror','Games','Permainan bertema seram.','☾','/games/profile',['Profil permainan','Kemajuan']),
 Feature('Chess Master','Games','Permainan catur.','♟','/games/profile',['Profil permainan','Kemajuan']),
 Feature('Tug of War','Games','Permainan tarik tali.','↔','/games/profile',['Profil permainan','Kemajuan']),
 Feature('IQ Master','Games','Kuiz dan cabaran IQ.','?', '/games/daily-quiz',['Daily Quiz','Profil permainan']),
 Feature('Ular Tangga','Games','Permainan papan ular dan tangga.','▦','/games/profile',['Profil permainan','Kemajuan']),
 Feature('Hexagram Stories','Media','Stories dan perkongsian media.','▣','/hexagram/stories',['Muat stories','Muat naik story']),
 Feature('YouTube & Music','Media','Carian kandungan media.','♫','',['Cari YouTube','Cari lagu']),
 Feature('Berita RSS','Content','Sumber berita RSS.','≋','',['Antara','Detik News','Kompas']),
 Feature('Cuaca','Content','Cuaca melalui API dan lokasi.','☼','',['Semak cuaca']),
 Feature('Waktu Solat','Content','Jadual waktu solat melalui API.','☾','',['Semak waktu solat']),
 Feature('NGL Helper','Content','Pautan dan panduan NGL.','↗','',['Buka NGL']),
 Feature('Voucher','Account','Tebus voucher akaun.','◇','/redeemVoucher',['Tebus voucher']),
 Feature('Script Bot','System','Pengurusan fail skrip bot.','⌘','/script-bot/files',['Senarai fail','Muat naik fail']),
 Feature('Sender Manager','System','Pengurusan sender dan pairing.','⇄','/mySenderFiles',['Senarai fail sender','Tambah Global Sender','Tambah Private Sender','Confirm Global Sender','Hapus Sender Saya','Reset sender']),
 Feature('Bug Management','System','Paparan penjelasan bug daripada server.','⚙','/getBugExplanations',['Muat penjelasan bug']),
 Feature('Owner Dashboard','Admin','Ringkasan status dan operasi Owner.','▦','/owner/status',['Semak status Owner']),
 Feature('User Management','Admin','Pengurusan akaun melalui API asal.','♙','/listUsers',['Senarai pengguna']),
 Feature('Device Dashboard','Admin','Pengurusan peranti dan log peranti.','▣','/getDeviceLogs',['Muat log peranti']),
 Feature('Content Manager','Admin','Pengurusan kandungan dan pengumuman.','▤','/owner/notifications',['Muat kandungan']),
 Feature('Update Center','Admin','Status aplikasi dan changelog.','↻','/app/changelog',['Semak changelog','Semak status aplikasi']),
 Feature('Security Center','Admin','Status sesi dan kawalan keselamatan.','⛨','/revokeSessions',['Semak sesi']),
 Feature('Owner AI Settings','Admin','Tetapan dan pengetahuan AI.','✦','/owner/ai/settings',['Muat tetapan AI']),
 Feature('Backup & Restore','Admin','Pengurusan backup Admin baharu.','⤓','/owner/backups',['Senarai backup']),
 Feature('Voucher Management','Admin','Pengurusan voucher oleh Owner.','◇','/owner/vouchers',['Senarai voucher']),
 Feature('Polling & Events','Admin','Pengurusan polling dan acara.','▤','/owner/polls',['Senarai polling','Senarai acara']),
 Feature('Notifications','Admin','Notifikasi Owner dan pengguna.','♢','/owner/notifications',['Senarai notifikasi']),
 Feature('Owner Control Center','Admin','Pusat kawalan dan status Owner.','⌘','/owner/control-center',['Semak status Owner']),
 Feature('Owner Events','Admin','Pengurusan acara oleh Owner.','◷','/owner/events',['Senarai acara']),
 Feature('Owner Polls','Admin','Pengurusan polling oleh Owner.','☷','/owner/polls',['Senarai polling']),
 Feature('Owner Vouchers','Admin','Pengurusan voucher Owner.','◇','/owner/vouchers',['Senarai voucher']),
 Feature('Owner AI Knowledge','Admin','Pengurusan pengetahuan AI.','✦','/owner/ai/knowledge',['Muat pengetahuan AI']),
 Feature('Owner Backups','Admin','Senarai backup backend Owner.','⤓','/owner/backups',['Senarai backup']),
 Feature('Device Permissions','Admin','Semakan kebenaran peranti.','▣','/listDevicePermissions',['Senarai kebenaran peranti']),
 Feature('App Bootstrap','System','Konfigurasi awal dan feature flags aplikasi.','↻','/app/bootstrap',['Muat konfigurasi awal']),
 Feature('Remote Feature Control','Admin','Semakan kawalan ciri jauh.','⚙','/owner/control-center',['Semak kawalan jauh']),
 Feature('Public Chat Moderation','Admin','Semakan mesej awam untuk moderasi.','◉','/getPublicChat',['Muat mesej awam']),
];

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState()=>_HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
 int tab=0; final search=TextEditingController(); String query='';
 @override Widget build(BuildContext context) {
  final filtered=features.where((f)=>('${f.name} ${f.category} ${f.description}').toLowerCase().contains(query.toLowerCase())).toList();
  return Scaffold(appBar: AppBar(title: const Text('ZENA V1.1',style:TextStyle(fontFamily:'Orbitron',fontWeight:FontWeight.bold)), actions:[IconButton(onPressed:()=>_openSettings(context),icon:const Icon(Icons.settings_outlined))]),
   drawer: Drawer(child: ListView(children:[DrawerHeader(decoration:const BoxDecoration(color:Color(0xFF211B38)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Image.asset('assets/images/logo.png',height:56,errorBuilder:(_,__,___)=>const Icon(Icons.bolt,size:40)),const SizedBox(height:8),const Text('Zena V1.1',style:TextStyle(fontFamily:'Orbitron'))])), for(final t in ['Dashboard','Semua Fitur','Admin Baharu','Tetapan']) ListTile(title:Text(t),onTap:(){Navigator.pop(context);setState(()=>tab=['Dashboard','Semua Fitur','Admin Baharu','Tetapan'].indexOf(t));})])),
   body: tab==2 ? const AdminScreen() : tab==3 ? _settingsPage() : tab==0 ? _dashboard(filtered) : _featureList(filtered),
   bottomNavigationBar: NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),NavigationDestination(icon:Icon(Icons.apps),label:'Fitur'),NavigationDestination(icon:Icon(Icons.admin_panel_settings_outlined),label:'Admin'),NavigationDestination(icon:Icon(Icons.settings_outlined),label:'Tetapan')]),
  );
 }
 Widget _dashboard(List<Feature> filtered)=>ListView(padding:const EdgeInsets.all(16),children:[
  Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(borderRadius:BorderRadius.circular(20),gradient:const LinearGradient(colors:[Color(0xFF31265B),Color(0xFF151521)])),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('WELCOME TO ZENA',style:TextStyle(fontFamily:'Orbitron',fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:8),const Text('AI • SOCIAL • TOOLS • GAMES • MEDIA'),const SizedBox(height:14),Image.asset('assets/images/banner.jpg',height:110,width:double.infinity,fit:BoxFit.cover,errorBuilder:(_,__,___)=>const SizedBox.shrink())]),),
  const SizedBox(height:18),TextField(controller:search,onChanged:(v)=>setState(()=>query=v),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Cari semua fitur...',border:OutlineInputBorder())),const SizedBox(height:18),
  const Text('Akses Pantas',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:10),GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,mainAxisSpacing:10,crossAxisSpacing:10,childAspectRatio:1.35,children:filtered.take(8).map(_featureCard).toList()),const SizedBox(height:18),const Text('Semua Modul',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:10),..._groupedCards(filtered),
 ]);
 Widget _featureList(List<Feature> list)=>ListView(padding:const EdgeInsets.all(16),children:[TextField(controller:search,onChanged:(v)=>setState(()=>query=v),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Cari fitur...',border:OutlineInputBorder())),const SizedBox(height:12),...list.map((f)=>_featureTile(f))]);
 List<Widget> _groupedCards(List<Feature> list){final groups=<String,List<Feature>>{};for(final f in list){groups.putIfAbsent(f.category,()=>[]).add(f);}return groups.entries.map((e)=>Padding(padding:const EdgeInsets.only(bottom:14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(e.key,style:const TextStyle(color:purple,fontSize:16,fontWeight:FontWeight.bold)),const SizedBox(height:7),...e.value.take(4).map(_featureTile)]))).toList();}
 Widget _featureCard(Feature f)=>InkWell(onTap:()=>_openFeature(f),borderRadius:BorderRadius.circular(16),child:Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:const Color(0xFF171722),borderRadius:BorderRadius.circular(16),border:Border.all(color:purple.withOpacity(.25))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(f.icon,style:const TextStyle(fontSize:23,color:purple)),const Spacer(),Text(f.name,style:const TextStyle(fontWeight:FontWeight.bold)),Text(f.category,style:const TextStyle(color:Colors.white54,fontSize:12))])));
 Widget _featureTile(Feature f)=>Card(child:ListTile(leading:CircleAvatar(backgroundColor:purple.withOpacity(.15),child:Text(f.icon,style:const TextStyle(color:purple))),title:Text(f.name),subtitle:Text(f.description,maxLines:2,overflow:TextOverflow.ellipsis),trailing:const Icon(Icons.chevron_right),onTap:()=>_openFeature(f)));
 void _openFeature(Feature f)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>f.category=='Games'?ZenaGameScreen(gameName:f.name):FeatureScreen(feature:f)));
 Widget _settingsPage()=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Tetapan',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:12),const ListTile(leading:Icon(Icons.info_outline),title:Text('Zena V1.1 Reconstruction'),subtitle:Text('UI dan integrasi API berdasarkan modul yang dikenal pasti.')),ListTile(leading:const Icon(Icons.open_in_new),title:const Text('Buka laman API'),onTap:()=>launchUrl(Uri.parse(ApiService.legacyBase),mode:LaunchMode.externalApplication)),const ListTile(leading:Icon(Icons.security),title:Text('Privasi dan kebenaran'),subtitle:Text('Lokasi hanya digunakan selepas kebenaran diberikan.'))]);
 void _openSettings(BuildContext context)=>setState(()=>tab=3);
}

class FeatureScreen extends StatefulWidget {
  final Feature feature;
  const FeatureScreen({super.key, required this.feature});
  @override
  State<FeatureScreen> createState() => _FeatureScreenState();
}

class _FeatureScreenState extends State<FeatureScreen> {
  final input = TextEditingController();
  final secret = TextEditingController();
  final picker = ImagePicker();
  final AudioRecorder recorder = AudioRecorder();
  bool recording = false;
  String output = 'Pilih tindakan untuk bermula.';
  bool busy = false;

  @override
  void dispose() {
    input.dispose();
    secret.dispose();
    recorder.dispose();
    super.dispose();
  }

  Future<void> run(String action) async {
    if (busy) return;
    setState(() { busy = true; output = 'Sedang memproses…'; });
    try {
      final f = widget.feature;
      dynamic result;
      final value = input.text.trim();

      if (f.name == 'QR Generator') {
        if (value.isEmpty) throw Exception('Masukkan teks atau URL untuk menjana QR.');
        result = {'status': 'ready', 'data': value, 'message': 'QR dipaparkan di bawah.'};
      } else if (f.name == 'Login & Account' && action == 'Login') {
        if (value.isEmpty || secret.text.isEmpty) throw Exception('Username dan kata laluan diperlukan.');
        result = await ApiService.postLegacy('/validate', {'username': value, 'password': secret.text});
      } else if (f.name == 'Create Account') {
        if (value.length < 3 || secret.text.length < 8) throw Exception('Username minimum 3 aksara dan kata laluan minimum 8 aksara.');
        result = await ApiService.postLegacy('/createAccount', {'username': value, 'password': secret.text});
      } else if (f.name == 'Account Recovery' || f.name == 'Change Password') {
        result = {'status': 'not_configured', 'message': 'Endpoint backend asal untuk ${f.name} tidak dapat dikenal pasti dengan selamat. Tiada data dihantar.'};
      } else if (f.name == 'My Profile') {
        result = await ApiService.getLegacy('/myInfo');
      } else if (f.name == 'Device Sessions') {
        result = action.contains('Tarik balik')
            ? await ApiService.postLegacy('/revokeSessions', {'scope': 'other'})
            : await ApiService.getLegacy('/getDeviceLogs');
      } else if (f.name == 'AI Assistant') {
        if (action == 'AI Knowledge') {
          result = await ApiService.getLegacy('/ai/knowledge');
        } else if (action == 'Tetapan AI') {
          result = await ApiService.getLegacy('/owner/ai/settings');
        } else {
          if (value.isEmpty) throw Exception('Taip soalan terlebih dahulu.');
          result = await ApiService.postLegacy('/ai/ask', {'question': value});
        }
      } else if (f.name == 'Chat Global') {
        if (action == 'Muat mesej') {
          result = await ApiService.getLegacy('/getPublicChat');
        } else if (action == 'Hantar mesej') {
          if (value.isEmpty) throw Exception('Mesej tidak boleh kosong.');
          result = await ApiService.postLegacy('/sendPublicChat', {'message': value});
        } else if (action == 'Hantar imej') {
          final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
          if (file == null) throw Exception('Pemilihan imej dibatalkan.');
          result = await ApiService.uploadLegacy('/sendPublicImage', await file.readAsBytes(), file.name);
        } else {
          if (!recording) {
            if (!await recorder.hasPermission()) throw Exception('Kebenaran mikrofon tidak diberikan.');
            final directory = await getTemporaryDirectory();
            final path = '${directory.path}/zena_voice_${DateTime.now().millisecondsSinceEpoch}.m4a';
            await recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: path);
            if (mounted) setState(() { recording = true; output = 'Sedang merakam. Tekan butang voice note sekali lagi untuk berhenti dan menghantar.'; });
            return;
          }
          final path = await recorder.stop();
          if (mounted) setState(() => recording = false);
          if (path == null) throw Exception('Rakaman tidak dijumpai.');
          final audio = await File(path).readAsBytes();
          result = await ApiService.uploadLegacy('/sendPublicVoice', audio, 'zena_voice.m4a');
        }
      } else if (f.name == 'Chat Peribadi') {
        if (action.startsWith('Hantar mesej')) {
          final parts = value.split('|');
          if (parts.length < 2 || parts.first.trim().isEmpty || parts.skip(1).join('|').trim().isEmpty) throw Exception('Gunakan format username|mesej.');
          result = await ApiService.postLegacy('/sendPrivateChat', {'username': parts.first.trim(), 'message': parts.skip(1).join('|').trim()});
        } else if (action.startsWith('Muat chat')) {
          if (value.isEmpty) throw Exception('Masukkan username penerima.');
          result = await ApiService.getLegacy('/getPrivateChat', query: {'username': value});
        } else {
          result = await ApiService.getLegacy('/social/users', query: value.isEmpty ? null : {'q': value});
        }
      } else if (f.name == 'Profil & Follow') {
        if (action == 'Senarai following') {
          result = await ApiService.getLegacy('/social/following');
        } else if (action == 'Follow pengguna') {
          if (value.isEmpty) throw Exception('Masukkan username pengguna.');
          result = await ApiService.postLegacy('/social/follow', {'username': value, 'action': 'follow'});
        } else if (action == 'Unfollow pengguna') {
          if (value.isEmpty) throw Exception('Masukkan username pengguna.');
          result = await ApiService.postLegacy('/social/follow', {'username': value, 'action': 'unfollow'});
        } else {
          result = await ApiService.getLegacy('/social/users', query: value.isEmpty ? null : {'q': value});
        }
      } else if (f.name == 'Domain OSINT') {
        final domain = _cleanDomain(value);
        if (action.toLowerCase().contains('subdomain')) {
          result = await _externalGet(Uri.https('crt.sh', '/', {'q': '%.$domain', 'output': 'json'}));
          if (result is List) {
            final names = <String>{};
            for (final row in result) {
              if (row is Map && row['name_value'] != null) {
                names.addAll(row['name_value'].toString().split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty && !e.startsWith('*')));
              }
            }
            result = {'domain': domain, 'subdomains': names.toList()..sort(), 'count': names.length, 'source': 'crt.sh'};
          }
        } else {
          final answers = await Future.wait([
            _externalGet(Uri.https('dns.google', '/resolve', {'name': domain, 'type': 'A'})),
            _externalGet(Uri.https('dns.google', '/resolve', {'name': domain, 'type': 'MX'})),
            _externalGet(Uri.https('dns.google', '/resolve', {'name': domain, 'type': 'NS'})),
          ]);
          result = {'domain': domain, 'A': answers[0]['Answer'] ?? [], 'MX': answers[1]['Answer'] ?? [], 'NS': answers[2]['Answer'] ?? [], 'source': 'Google DNS-over-HTTPS'};
        }
      } else if (f.name == 'IP & GPS' && action == 'Semak IP awam') {
        result = await _externalGet(Uri.https('api.ipify.org', '/', {'format': 'json'}));
      } else if (f.name == 'IP & GPS' && action == 'Dapatkan GPS') {
        var enabled = await Geolocator.isLocationServiceEnabled();
        if (!enabled) throw Exception('Aktifkan Location pada peranti dahulu.');
        var permission = await Geolocator.checkPermission();
        if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) throw Exception('Kebenaran lokasi tidak diberikan.');
        final position = await Geolocator.getCurrentPosition();
        result = {'latitude': position.latitude, 'longitude': position.longitude, 'accuracy_m': position.accuracy};
      } else if (f.name == 'QR Generator') {
        result = {'data': value};
      } else if (f.name == 'Instagram Downloader') {
        final uri = _validatedSocialUrl(value, 'instagram.com');
        result = await _externalGet(Uri.https('api.siputzx.my.id', '/api/d/igdl', {'url': uri.toString()}));
      } else if (f.name == 'TikTok Downloader') {
        final uri = _validatedSocialUrl(value, 'tiktok.com');
        result = await _externalGet(Uri.https('api.siputzx.my.id', '/api/d/ttdl', {'url': uri.toString()}));
      } else if (f.name == 'Email OSINT') {
        final parts = value.split('@');
        if (parts.length != 2 || !parts[1].contains('.')) throw Exception('Masukkan alamat e-mel yang sah.');
        final domain = _cleanDomain(parts[1]);
        result = await _externalGet(Uri.https('dns.google', '/resolve', {'name': domain, 'type': 'MX'}));
        result = {'email_domain': domain, 'mx_records': result['Answer'] ?? [], 'note': 'Semakan DNS domain sahaja; bukan pengesahan pemilik e-mel.'};
      } else if (f.name == 'Phone Lookup') {
        final normalized = value.replaceAll(RegExp(r'[\s()\-]'), '');
        if (!RegExp(r'^\+?[0-9]{7,15}$').hasMatch(normalized)) throw Exception('Format nombor tidak sah. Gunakan 7–15 digit dan kod negara jika diketahui.');
        result = {'number_format': 'valid', 'normalized': normalized, 'note': 'Format sahaja disahkan. Tiada carian identiti atau lokasi pemilik dibuat.'};
      } else if (f.name == 'NIK Checker') {
        final digits = value.replaceAll(RegExp(r'\D'), '');
        result = {'format_valid': digits.length == 16, 'digits': digits.length, 'note': 'Pengesahan format sahaja. Nombor pengenalan tidak dihantar ke servis pihak ketiga.'};
      } else if (f.name == 'Proxy Settings') {
        result = {'guide': ['Android Settings > Network & Internet > Internet', 'Pilih rangkaian Wi-Fi yang disambungkan', 'Buka Edit / Advanced options', 'Tetapkan Proxy hanya jika anda mempunyai host dan port yang sah'], 'note': 'Aplikasi tidak mengubah tetapan proxy sistem secara automatik.'};
      } else if (f.name == 'WiFi Tools') {
        final response = await http.get(Uri.https('connectivitycheck.gstatic.com', '/generate_204')).timeout(const Duration(seconds: 12));
        result = {'reachable': response.statusCode == 204 || response.statusCode == 200, 'http_status': response.statusCode, 'note': 'Ujian sambungan sahaja; tidak mengganggu rangkaian.'};
      } else if (f.name == 'Server Manager') {
        if (action.contains('Tambah server')) result = await ApiService.postLegacy('/addServer', {'server': value});
        else if (action.contains('Padam server')) result = await ApiService.postLegacy('/delServer', {'server': value});
        else result = await ApiService.getLegacy('/myServer');
      } else if (f.name == 'Hexagram Stories') {
        if (action == 'Muat stories') {
          result = await ApiService.getLegacy('/hexagram/stories');
        } else {
          final file = await picker.pickMedia(imageQuality: 85);
          if (file == null) throw Exception('Pemilihan media dibatalkan.');
          result = await ApiService.uploadLegacy('/hexagram/stories/upload', await file.readAsBytes(), file.name);
        }
      } else if (f.name == 'YouTube & Music') {
        if (value.isEmpty) throw Exception('Masukkan tajuk carian.');
        final url = action == 'Cari lagu'
            ? Uri.https('www.youtube.com', '/results', {'search_query': '$value music'})
            : Uri.https('www.youtube.com', '/results', {'search_query': value});
        await launchUrl(url, mode: LaunchMode.externalApplication);
        result = {'opened': url.toString()};
      } else if (f.name == 'Berita RSS') {
        final url = action == 'Detik News'
            ? 'https://rss.detik.com/index.php/detikcom'
            : action == 'Kompas'
                ? 'https://rss.kompas.com/'
                : 'https://www.antaranews.com/rss/terkini.xml';
        final response = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 20));
        if (response.statusCode < 200 || response.statusCode >= 300) throw Exception('RSS HTTP ${response.statusCode}');
        final document = XmlDocument.parse(response.body);
        result = document.findAllElements('item').take(20).map((item) => {'title': item.getElement('title')?.innerText ?? '', 'link': item.getElement('link')?.innerText ?? '', 'date': item.getElement('pubDate')?.innerText ?? ''}).toList();
      } else if (f.name == 'Cuaca') {
        if (value.isEmpty) throw Exception('Masukkan nama bandar.');
        final geocode = await _externalGet(Uri.https('geocoding-api.open-meteo.com', '/v1/search', {'name': value, 'count': '1', 'language': 'ms', 'format': 'json'}));
        final places = geocode['results'] as List?;
        if (places == null || places.isEmpty) throw Exception('Bandar tidak ditemui.');
        final place = places.first as Map;
        final weather = await _externalGet(Uri.https('api.open-meteo.com', '/v1/forecast', {'latitude': '${place['latitude']}', 'longitude': '${place['longitude']}', 'current': 'temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m', 'timezone': 'auto'}));
        result = {'location': '${place['name']}, ${place['country']}', 'current': weather['current'], 'units': weather['current_units'], 'source': 'Open-Meteo'};
      } else if (f.name == 'Waktu Solat') {
        final uri = Uri.https('api.aladhan.com', '/v1/timingsByCity', {'city': value.isEmpty ? 'Alor Setar' : value, 'country': 'Malaysia', 'method': '3'});
        result = await _externalGet(uri);
      } else if (f.name == 'NGL Helper') {
        await launchUrl(Uri.https('ngl.link', '/'), mode: LaunchMode.externalApplication);
        result = {'message': 'NGL dibuka dalam pelayar.'};
      } else if (f.name == 'Voucher') {
        if (value.isEmpty) throw Exception('Masukkan kod voucher.');
        result = await ApiService.postLegacy('/redeemVoucher', {'code': value});
      } else if (f.name == 'Script Bot') {
        if (action == 'Muat naik fail') {
          final selected = await FilePicker.platform.pickFiles(withData: true);
          if (selected == null || selected.files.isEmpty) throw Exception('Pemilihan fail dibatalkan.');
          final picked = selected.files.first;
          final bytes = picked.bytes ?? (picked.path != null ? await File(picked.path!).readAsBytes() : null);
          if (bytes == null) throw Exception('Fail tidak dapat dibaca.');
          result = await ApiService.uploadLegacy('/script-bot/upload', bytes, picked.name);
        } else {
          result = await ApiService.getLegacy('/script-bot/files');
        }
      } else if (f.name == 'Sender Manager') {
        if (action.contains('Reset')) result = await ApiService.postLegacy('/resetSender', {});
        else if (action == 'Tambah Global Sender') result = await ApiService.postLegacy('/addGlobalSender', {'value': value});
        else if (action == 'Tambah Private Sender') result = await ApiService.postLegacy('/addPrivateSender', {'value': value});
        else if (action == 'Confirm Global Sender') result = await ApiService.postLegacy('/confirmGlobalSender', {'value': value});
        else if (action == 'Hapus Sender Saya') result = await ApiService.postLegacy('/deleteSender', {'value': value});
        else result = await ApiService.getLegacy('/mySenderFiles');
      } else if (f.name == 'Bug Management') {
        result = await ApiService.getLegacy('/getBugExplanations');
      } else if (f.name == 'Owner Control Center' || f.name == 'Remote Feature Control') {
        result = await ApiService.getLegacy('/owner/control-center');
      } else if (f.name == 'Owner Events') {
        result = await ApiService.getLegacy('/owner/events');
      } else if (f.name == 'Owner Polls') {
        result = await ApiService.getLegacy('/owner/polls');
      } else if (f.name == 'Owner Vouchers') {
        result = await ApiService.getLegacy('/owner/vouchers');
      } else if (f.name == 'Owner AI Knowledge') {
        result = await ApiService.getLegacy('/owner/ai/knowledge');
      } else if (f.name == 'Owner Backups') {
        result = await ApiService.getLegacy('/owner/backups');
      } else if (f.name == 'Device Permissions') {
        result = await ApiService.getLegacy('/listDevicePermissions');
      } else if (f.name == 'App Bootstrap') {
        result = await ApiService.getLegacy('/app/bootstrap');
      } else if (f.name == 'Public Chat Moderation') {
        result = await ApiService.getLegacy('/getPublicChat');
      } else if (f.name == 'Owner Dashboard') {
        result = await ApiService.getLegacy('/owner/status');
      } else if (f.name == 'User Management') {
        result = await ApiService.getLegacy('/listUsers');
      } else if (f.name == 'Device Dashboard') {
        result = await ApiService.getLegacy('/getDeviceLogs');
      } else if (f.name == 'Content Manager' || f.name == 'Notifications') {
        result = await ApiService.getLegacy('/owner/notifications');
      } else if (f.name == 'Update Center') {
        result = await ApiService.getLegacy(action.contains('changelog') ? '/app/changelog' : '/app/status');
      } else if (f.name == 'Security Center') {
        result = await ApiService.getLegacy('/getDeviceLogs');
      } else if (f.name == 'Owner AI Settings') {
        result = await ApiService.getLegacy('/owner/ai/settings');
      } else if (f.name == 'Backup & Restore') {
        result = await ApiService.getAdmin('/api/admin/backups');
      } else if (f.name == 'Voucher Management') {
        result = await ApiService.getLegacy('/owner/vouchers');
      } else if (f.name == 'Polling & Events') {
        result = await ApiService.getLegacy(action.contains('acara') ? '/owner/events' : '/owner/polls');
      } else if (f.endpoint.isNotEmpty) {
        result = await ApiService.getLegacy(f.endpoint);
      } else {
        result = {'status': 'local_only', 'feature': f.name, 'action': action, 'message': 'Tindakan ini tidak memerlukan server atau endpoint khusus yang dikenal pasti.'};
      }
      if (mounted) setState(() => output = JsonEncoder.withIndent('  ').convert(result));
    } catch (error) {
      if (mounted) setState(() => output = 'Ralat: $error');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  String _cleanDomain(String value) {
    var domain = value.trim().toLowerCase().replaceFirst(RegExp(r'^https?://'), '').split('/').first.split(':').first;
    if (domain.isEmpty || !RegExp(r'^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$').hasMatch(domain)) {
      throw Exception('Masukkan domain sah, contoh example.com.');
    }
    return domain;
  }

  Uri _validatedSocialUrl(String value, String allowedDomain) {
    final uri = Uri.tryParse(value);
    if (uri == null || !uri.hasScheme || !{'http', 'https'}.contains(uri.scheme) || !(uri.host == allowedDomain || uri.host.endsWith('.$allowedDomain'))) {
      throw Exception('Masukkan pautan https:// yang sah dari $allowedDomain.');
    }
    return uri;
  }

  Future<dynamic> _externalGet(Uri uri) async {
    final response = await http.get(uri, headers: {'Accept': 'application/json'}).timeout(const Duration(seconds: 25));
    if (response.statusCode < 200 || response.statusCode >= 300) throw Exception('Servis luar HTTP ${response.statusCode}.');
    try { return jsonDecode(response.body); } catch (_) { return response.body; }
  }

  @override
  Widget build(BuildContext context) {
    final f = widget.feature;
    final needsSecret = f.name == 'Login & Account' || f.name == 'Create Account';
    final noInput = f.name == 'NGL Helper' || f.name == 'YouTube & Music' || f.name == 'Berita RSS';
    return Scaffold(
      appBar: AppBar(title: Text(f.name)),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFF191827), borderRadius: BorderRadius.circular(16)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(f.icon, style: const TextStyle(fontSize: 32, color: purple)), Text(f.description, style: const TextStyle(fontSize: 16)), const SizedBox(height: 8), Text('Kategori: ${f.category}', style: const TextStyle(color: Colors.white54))])),
        const SizedBox(height: 16),
        if (!noInput) TextField(controller: input, maxLines: 2, decoration: InputDecoration(labelText: _hint(f.name), hintText: _hint(f.name), border: const OutlineInputBorder())),
        if (needsSecret) Padding(padding: const EdgeInsets.only(top: 12), child: TextField(controller: secret, obscureText: true, decoration: const InputDecoration(labelText: 'Kata laluan', border: OutlineInputBorder()))),
        if (f.name == 'QR Generator' && input.text.trim().isNotEmpty) Padding(padding: const EdgeInsets.only(top: 16), child: Center(child: QrImageView(data: input.text.trim(), size: 200, backgroundColor: Colors.white))),
        const SizedBox(height: 14),
        ...f.actions.map((action) => Padding(padding: const EdgeInsets.only(bottom: 8), child: FilledButton.icon(onPressed: busy ? null : () => run(action), icon: const Icon(Icons.play_arrow), label: Text(f.name == 'Chat Global' && action == 'Hantar voice note' && recording ? 'Berhenti dan hantar voice note' : action)))),
        const SizedBox(height: 12),
        const Text('Output', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Container(width: double.infinity, padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFF15151E), borderRadius: BorderRadius.circular(12)), child: SelectableText(busy ? 'Memproses…' : output)),
      ]),
    );
  }

  String _hint(String name) => switch (name) {
    'Login & Account' => 'Username', 'Create Account' => 'Username',
    'AI Assistant' => 'Taip soalan untuk AI', 'Chat Global' => 'Mesej / input',
    'Chat Peribadi' => 'Carian username, atau username|mesej untuk hantar chat', 'Profil & Follow' => 'Username pengguna',
    'Domain OSINT' => 'Masukkan domain, contoh example.com', 'IP & GPS' => 'Tidak perlu input untuk IP/GPS',
    'Instagram Downloader' => 'Tampal URL Instagram', 'TikTok Downloader' => 'Tampal URL TikTok',
    'Email OSINT' => 'Alamat e-mel (semakan DNS domain sahaja)', 'Phone Lookup' => 'Nombor dengan kod negara',
    'NIK Checker' => '16 digit (semakan format sahaja)', 'QR Generator' => 'Teks atau URL untuk QR',
    'Voucher' => 'Kod voucher', 'Cuaca' => 'Nama bandar', 'Waktu Solat' => 'Nama bandar',
    'Server Manager' => 'Alamat atau ID server', 'Hexagram Stories' => 'Pilih tindakan di bawah',
    _ => 'Input diperlukan jika berkenaan',
  };
}
