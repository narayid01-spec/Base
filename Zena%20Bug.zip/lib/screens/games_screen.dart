import 'dart:math';
import 'package:flutter/material.dart';

/// Offline playable mini-games reconstructed from the feature names exposed by Zena V1.1.
/// These are original lightweight implementations, not recovered original game source.
class ZenaGameScreen extends StatefulWidget {
  final String gameName;
  const ZenaGameScreen({super.key, required this.gameName});
  @override
  State<ZenaGameScreen> createState() => _ZenaGameScreenState();
}

class _ZenaGameScreenState extends State<ZenaGameScreen> {
  final Random _random = Random();
  int score = 0;
  int round = 1;
  int target = 0;
  int hazardLane = 1;
  int playerLane = 1;
  int tug = 0;
  int boardPosition = 0;
  int doorMonster = 0;
  bool gameOver = false;
  String message = 'Tekan Mula untuk bermain.';
  int quizIndex = 0;

  static const List<Map<String, Object>> _quiz = [
    {'q': 'Berapakah hasil 12 × 8?', 'a': ['86', '96', '108', '92'], 'correct': 1},
    {'q': 'Planet yang dikenali sebagai Planet Merah?', 'a': ['Zuhal', 'Bumi', 'Marikh', 'Utarid'], 'correct': 2},
    {'q': 'Apakah nombor perdana terkecil?', 'a': ['0', '1', '2', '3'], 'correct': 2},
    {'q': 'Berapakah jumlah sisi sebuah heksagon?', 'a': ['5', '6', '7', '8'], 'correct': 1},
    {'q': 'Apakah ibu negara Malaysia?', 'a': ['Johor Bahru', 'Kuala Lumpur', 'Kuching', 'Ipoh'], 'correct': 1},
  ];
  static const List<Map<String, Object>> _chessQuiz = [
    {'q': 'Buah catur manakah bergerak dalam bentuk L?', 'a': ['Benteng', 'Kuda', 'Gajah', 'Menteri'], 'correct': 1},
    {'q': 'Buah manakah paling penting untuk mengelakkan checkmate?', 'a': ['Raja', 'Bidak', 'Gajah', 'Kuda'], 'correct': 0},
    {'q': 'Buah manakah boleh bergerak secara diagonal?', 'a': ['Benteng sahaja', 'Gajah', 'Raja sahaja', 'Tiada'], 'correct': 1},
  ];
  static const Map<int, int> _snakes = {17: 7, 54: 34, 62: 19, 98: 79, 87: 24};
  static const Map<int, int> _ladders = {3: 22, 8: 30, 28: 55, 42: 73, 58: 77, 75: 95};

  void _start() {
    setState(() {
      score = 0;
      round = 1;
      tug = 0;
      boardPosition = 0;
      gameOver = false;
      target = _random.nextInt(16);
      hazardLane = _random.nextInt(3);
      playerLane = 1;
      doorMonster = _random.nextInt(3);
      quizIndex = 0;
      message = 'Permainan bermula!';
    });
  }

  void _shoot(int cell) {
    setState(() {
      if (gameOver) return;
      if (cell == target) {
        score += 10;
        round++;
        target = _random.nextInt(16);
        message = 'Tepat! +10 mata.';
      } else {
        score = max(0, score - 2);
        message = 'Tersasar! Cuba sasarkan bintang.';
      }
    });
  }

  void _drive(int lane) {
    setState(() {
      if (gameOver) return;
      playerLane = lane;
      if (lane == hazardLane) {
        gameOver = true;
        message = 'Kemalangan! Skor akhir: $score.';
      } else {
        score += 5;
        round++;
        hazardLane = _random.nextInt(3);
        message = 'Bagus! +5 mata. Elak lorong halangan.';
      }
    });
  }

  void _door(int door) {
    setState(() {
      if (gameOver) return;
      if (door == doorMonster) {
        gameOver = true;
        message = 'Anda bertemu entiti! Skor akhir: $score.';
      } else {
        score += 10;
        round++;
        doorMonster = _random.nextInt(3);
        message = 'Selamat buat masa ini. Pilih pintu seterusnya.';
      }
    });
  }

  void _answer(int index, {required bool chess}) {
    setState(() {
      final questions = chess ? _chessQuiz : _quiz;
      final item = questions[quizIndex % questions.length];
      final answers = item['a'] as List<String>;
      final correct = item['correct'] as int;
      if (index == correct) {
        score += 10;
        message = 'Jawapan betul! +10 mata.';
      } else {
        message = 'Belum tepat. Jawapan: ${answers[correct]}';
      }
      quizIndex++;
      if (quizIndex >= questions.length) {
        gameOver = true;
        message = '$message Tamat! Skor: $score.';
      }
    });
  }

  void _rollDice() {
    setState(() {
      if (gameOver) return;
      final dice = _random.nextInt(6) + 1;
      var next = boardPosition + dice;
      if (next > 100) next = boardPosition;
      final before = next;
      if (_ladders.containsKey(next)) next = _ladders[next]!;
      if (_snakes.containsKey(next)) next = _snakes[next]!;
      boardPosition = next;
      score = boardPosition;
      if (boardPosition >= 100) {
        boardPosition = 100;
        gameOver = true;
        message = 'Tahniah! Anda menang dengan balingan $dice.';
      } else if (_ladders.containsKey(before)) {
        message = 'Dadu $dice: naik tangga ke petak $next.';
      } else if (_snakes.containsKey(before)) {
        message = 'Dadu $dice: terkena ular, turun ke petak $next.';
      } else {
        message = 'Dadu: $dice. Anda di petak $next.';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final name = widget.gameName;
    return Scaffold(
      appBar: AppBar(title: Text(name), actions: [IconButton(onPressed: _start, icon: const Icon(Icons.refresh), tooltip: 'Mula semula')]),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: const LinearGradient(colors: [Color(0xFF35265F), Color(0xFF171722)])),
            child: Row(children: [
              const Icon(Icons.sports_esports, size: 42, color: Color(0xFFB9A7FF)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                Text('Skor: $score  •  Pusingan: $round'),
                Text(message, style: const TextStyle(color: Colors.white70)),
              ])),
            ]),
          ),
          const SizedBox(height: 18),
          if (name == 'Galaxy Shooter') _galaxy(),
          if (name == 'Turbo Racer') _racer(),
          if (name == 'Dark Horror') _horror(),
          if (name == 'Chess Master') _quizGame(chess: true),
          if (name == 'IQ Master') _quizGame(chess: false),
          if (name == 'Tug of War') _tug(),
          if (name == 'Ular Tangga') _snakesAndLadders(),
          const SizedBox(height: 18),
          FilledButton.icon(onPressed: _start, icon: const Icon(Icons.play_arrow), label: const Text('Mula / Main Semula')),
          const SizedBox(height: 8),
          const Text('Permainan mini ini dibina semula untuk dimainkan secara offline. Ia bukan kod permainan asal yang dipulihkan daripada APK.', style: TextStyle(color: Colors.white54, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _galaxy() {
    return Column(children: [
      const Text('Tekan bintang yang menyala untuk menembak sasaran.'),
      const SizedBox(height: 10),
      GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: 16,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, crossAxisSpacing: 8, mainAxisSpacing: 8),
        itemBuilder: (_, i) => FilledButton(
          onPressed: gameOver ? null : () => _shoot(i),
          style: FilledButton.styleFrom(backgroundColor: i == target ? const Color(0xFF8B5CF6) : const Color(0xFF20202E)),
          child: Icon(i == target ? Icons.star : Icons.circle_outlined, color: i == target ? Colors.amber : Colors.white24),
        ),
      ),
    ]);
  }

  Widget _racer() {
    return Column(children: [
      const Text('Pilih lorong yang tidak mempunyai halangan.'),
      const SizedBox(height: 12),
      Row(children: List.generate(3, (i) => Expanded(child: Padding(
        padding: const EdgeInsets.all(4),
        child: Container(
          height: 180,
          decoration: BoxDecoration(color: i == hazardLane ? const Color(0xFF512A38) : const Color(0xFF20202E), borderRadius: BorderRadius.circular(12), border: Border.all(color: i == playerLane ? Colors.deepPurpleAccent : Colors.white12)),
          child: Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            Icon(i == hazardLane ? Icons.warning_amber : Icons.route, size: 34, color: i == hazardLane ? Colors.orangeAccent : Colors.white54),
            Text('Lorong ${i + 1}'),
            if (i == playerLane) const Icon(Icons.directions_car, color: Colors.lightBlueAccent),
          ]),
        ),
      )))),
      const SizedBox(height: 10),
      Wrap(spacing: 8, children: List.generate(3, (i) => FilledButton(onPressed: gameOver ? null : () => _drive(i), child: Text('Lorong ${i + 1}')))),
    ]);
  }

  Widget _horror() {
    return Column(children: [
      const Text('Pilih satu daripada tiga pintu. Elakkan pintu berhantu.'),
      const SizedBox(height: 12),
      Row(children: List.generate(3, (i) => Expanded(child: Padding(
        padding: const EdgeInsets.all(4),
        child: FilledButton.tonal(
          onPressed: gameOver ? null : () => _door(i),
          style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 28)),
          child: Column(children: [Icon(gameOver && i == doorMonster ? Icons.dangerous : Icons.door_front_door, size: 38), Text('Pintu ${i + 1}')]),
        ),
      )))),
    ]);
  }

  Widget _quizGame({required bool chess}) {
    final questions = chess ? _chessQuiz : _quiz;
    final item = questions[quizIndex % questions.length];
    final answers = item['a'] as List<String>;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Text(chess ? 'Kuiz strategi catur' : 'Soalan IQ', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      Text(item['q'] as String, style: const TextStyle(fontSize: 17)),
      const SizedBox(height: 8),
      ...answers.asMap().entries.map((entry) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: OutlinedButton(onPressed: gameOver ? null : () => _answer(entry.key, chess: chess), child: Text(entry.value)),
      )),
    ]);
  }

  Widget _tug() {
    return Column(children: [
      const Text('Tekan Tarik! 25 tarikan diperlukan untuk menang.'),
      const SizedBox(height: 16),
      LinearProgressIndicator(value: tug / 25, minHeight: 14, borderRadius: BorderRadius.circular(20)),
      const SizedBox(height: 18),
      Text(tug >= 25 ? 'MENANG!' : 'Tarikan: $tug / 25', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      SizedBox(width: double.infinity, child: FilledButton.icon(
        onPressed: gameOver ? null : () => setState(() {
          tug++;
          score = tug * 4;
          message = tug >= 25 ? 'Anda menang tarik tali!' : 'Teruskan menarik!';
          if (tug >= 25) gameOver = true;
        }),
        icon: const Icon(Icons.touch_app),
        label: const Text('TARIK!'),
      )),
    ]);
  }

  Widget _snakesAndLadders() {
    return Column(children: [
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: const Color(0xFF20202E), borderRadius: BorderRadius.circular(14)),
        child: Column(children: [
          Text('PETAK $boardPosition / 100', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Wrap(spacing: 4, runSpacing: 4, children: List.generate(100, (i) {
            final n = i + 1;
            final active = n == boardPosition;
            final special = _snakes.containsKey(n) || _ladders.containsKey(n);
            return Container(
              width: 27,
              height: 27,
              alignment: Alignment.center,
              decoration: BoxDecoration(color: active ? Colors.deepPurpleAccent : special ? const Color(0xFF4B4266) : const Color(0xFF30303D), borderRadius: BorderRadius.circular(4)),
              child: Text('$n', style: TextStyle(fontSize: 9, color: active ? Colors.white : Colors.white70)),
            );
          })),
        ]),
      ),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: gameOver ? null : _rollDice, icon: const Icon(Icons.casino), label: const Text('Baling Dadu')),
    ]);
  }
}
