import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/api_service.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  bool logged = false;
  bool busy = false;
  bool mustChangePassword = false;
  bool isSuperAdmin = false;
  String message = '';
  final user = TextEditingController(text: 'adam');
  final pass = TextEditingController();
  dynamic stats;
  List<dynamic> users = [];
  List<dynamic> vouchers = [];
  List<dynamic> logs = [];
  List<dynamic> contentItems = [];
  List<dynamic> notifications = [];
  List<dynamic> events = [];
  List<dynamic> polls = [];
  List<dynamic> knowledge = [];
  List<dynamic> featureFlags = [];
  List<dynamic> backups = [];

  @override
  void initState() {
    super.initState();
    _check();
  }

  @override
  void dispose() {
    user.dispose();
    pass.dispose();
    super.dispose();
  }

  Future<void> _check() async {
    final prefs = await SharedPreferences.getInstance();
    if (prefs.getString('zena_admin_token') != null) {
      final mustChange = prefs.getBool('zena_admin_must_change') ?? false;
      final role = prefs.getString('zena_admin_role') ?? '';
      if (!mounted) return;
      setState(() { logged = true; mustChangePassword = mustChange; isSuperAdmin = role == 'SUPER_ADMIN'; });
      if (mustChange) { await _changeInitialPassword(); } else { await _load(); }
    }
  }

  Future<void> _login() async {
    setState(() => busy = true);
    try {
      final result = await ApiService.postAdmin(
        '/api/auth/login',
        {'username': user.text.trim(), 'password': pass.text},
        auth: false,
      );
      final account = result['user'];
      final role = account is Map ? account['role']?.toString() ?? 'USER' : 'USER';
      if (role != 'SUPER_ADMIN' && role != 'ADMIN') {
        final rejectedPrefs = await SharedPreferences.getInstance();
        await rejectedPrefs.setString('zena_admin_token', result['token'].toString());
        try { await ApiService.postAdmin('/api/auth/logout', {}); } catch (_) {}
        await rejectedPrefs.remove('zena_admin_token');
        throw Exception('Akaun ini bukan Admin.');
      }
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('zena_admin_token', result['token'].toString());
      await prefs.setString('zena_admin_role', role);
      final mustChange = account is Map && account['must_change_password'] == true;
      await prefs.setBool('zena_admin_must_change', mustChange);
      if (!mounted) return;
      setState(() {
        logged = true;
        mustChangePassword = mustChange;
        isSuperAdmin = role == 'SUPER_ADMIN';
        message = mustChange ? 'Tukar kata laluan awal untuk meneruskan.' : 'Log masuk berjaya.';
      });
      if (mustChange) { await _changeInitialPassword(); } else { await _load(); }
    } catch (error) {
      setState(() => message = 'Login gagal: $error');
    } finally {
      setState(() => busy = false);
    }
  }

  Future<void> _load() async {
    setState(() => busy = true);
    try {
      final results = await Future.wait([
        ApiService.getAdmin('/api/admin/stats'),
        ApiService.getAdmin('/api/admin/users'),
        ApiService.getAdmin('/api/admin/vouchers'),
        ApiService.getAdmin('/api/admin/audit'),
        ApiService.getAdmin('/api/admin/content'),
        ApiService.getAdmin('/api/admin/notifications'),
        ApiService.getAdmin('/api/admin/events'),
        ApiService.getAdmin('/api/admin/polls'),
        ApiService.getAdmin('/api/admin/ai-knowledge'),
        ApiService.getAdmin('/api/admin/features'),
        ApiService.getAdmin('/api/admin/backups'),
      ]);
      setState(() {
        stats = results[0];
        users = (results[1]['users'] as List?) ?? [];
        vouchers = (results[2]['vouchers'] as List?) ?? [];
        logs = (results[3]['logs'] as List?) ?? [];
        contentItems = (results[4]['items'] as List?) ?? [];
        notifications = (results[5]['notifications'] as List?) ?? [];
        events = (results[6]['events'] as List?) ?? [];
        polls = (results[7]['polls'] as List?) ?? [];
        knowledge = (results[8]['items'] as List?) ?? [];
        featureFlags = (results[9]['features'] as List?) ?? [];
        backups = (results[10]['backups'] as List?) ?? [];
        message = 'Data dikemas kini.';
      });
    } catch (error) {
      setState(() => message = 'Backend Admin belum disambungkan atau tidak dapat dicapai: $error');
    } finally {
      setState(() => busy = false);
    }
  }

  Future<void> _logout() async {
    try { await ApiService.postAdmin('/api/auth/logout', {}); } catch (_) {}
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('zena_admin_token');
    await prefs.remove('zena_admin_must_change');
    await prefs.remove('zena_admin_role');
    setState(() {
      logged = false;
      mustChangePassword = false;
      isSuperAdmin = false;
      stats = null;
      users = [];
      vouchers = [];
      logs = [];
      contentItems = []; notifications = []; events = []; polls = []; knowledge = []; featureFlags = []; backups = [];
      pass.clear();
      message = '';
    });
  }

  Future<void> _changeInitialPassword() async {
    final current = TextEditingController(text: pass.text);
    final next = TextEditingController();
    final confirm = TextEditingController();
    final accepted = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Tukar kata laluan awal'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Untuk keselamatan, tukar kata laluan sementara sebelum menggunakan Admin.'),
          const SizedBox(height: 12),
          TextField(controller: current, obscureText: true, decoration: const InputDecoration(labelText: 'Kata laluan semasa')),
          TextField(controller: next, obscureText: true, decoration: const InputDecoration(labelText: 'Kata laluan baharu (min. 10 aksara)')),
          TextField(controller: confirm, obscureText: true, decoration: const InputDecoration(labelText: 'Ulang kata laluan baharu')),
        ])),
        actions: [FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Simpan dan teruskan'))],
      ),
    );
    if (accepted == true) {
      if (next.text.length < 10 || next.text != confirm.text) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pastikan kata laluan sekurang-kurangnya 10 aksara dan kedua-duanya sepadan.')));
        current.dispose(); next.dispose(); confirm.dispose();
        await _changeInitialPassword();
        return;
      }
      try {
        await ApiService.postAdmin('/api/auth/change-password', {'current_password': current.text, 'new_password': next.text});
        final prefs = await SharedPreferences.getInstance();
        await prefs.remove('zena_admin_must_change');
        if (mounted) setState(() { mustChangePassword = false; message = 'Kata laluan berjaya ditukar.'; });
        await _load();
      } catch (error) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal menukar kata laluan: $error')));
        current.dispose(); next.dispose(); confirm.dispose();
        await _changeInitialPassword();
        return;
      }
    } else {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('zena_admin_token');
      await prefs.remove('zena_admin_must_change');
      await prefs.remove('zena_admin_role');
      if (mounted) setState(() { logged = false; mustChangePassword = false; isSuperAdmin = false; });
    }
    current.dispose(); next.dispose(); confirm.dispose();
  }

  Future<void> _createRecord(String kind) async {
    final title = TextEditingController();
    final body = TextEditingController();
    final extra = TextEditingController();
    final accepted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(switch (kind) { 'content' => 'Tambah kandungan', 'notification' => 'Hantar notifikasi', 'event' => 'Tambah acara', 'poll' => 'Cipta polling', _ => 'Tambah pengetahuan AI' }),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: title, decoration: const InputDecoration(labelText: 'Tajuk')),
          TextField(controller: body, maxLines: 4, decoration: InputDecoration(labelText: kind == 'poll' ? 'Pilihan, pisahkan dengan koma' : kind == 'event' ? 'Penerangan acara' : kind == 'knowledge' ? 'Kandungan pengetahuan' : 'Kandungan')),
          if (kind == 'event') TextField(controller: extra, decoration: const InputDecoration(labelText: 'Tarikh / masa (teks)')),
        ])),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Simpan'))],
      ),
    );
    if (accepted == true) {
      try {
        String path;
        Map<String, dynamic> payload;
        switch (kind) {
          case 'content': path = '/api/admin/content'; payload = {'kind': 'announcement', 'title': title.text.trim(), 'body': body.text.trim()}; break;
          case 'notification': path = '/api/admin/notifications'; payload = {'title': title.text.trim(), 'body': body.text.trim(), 'target': 'ALL'}; break;
          case 'event': path = '/api/admin/events'; payload = {'title': title.text.trim(), 'description': body.text.trim(), 'event_date': extra.text.trim()}; break;
          case 'poll': path = '/api/admin/polls'; payload = {'title': title.text.trim(), 'options': body.text.split(',').map((v) => v.trim()).where((v) => v.isNotEmpty).toList()}; break;
          default: path = '/api/admin/ai-knowledge'; payload = {'title': title.text.trim(), 'content': body.text.trim()};
        }
        await ApiService.postAdmin(path, payload);
        await _load();
      } catch (error) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$error')));
      }
    }
    title.dispose(); body.dispose(); extra.dispose();
  }

  Future<void> _createBackup() async {
    try { await ApiService.postAdmin('/api/admin/backup', {}); await _load(); }
    catch (error) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$error'))); }
  }

  Future<void> _restoreBackup(String filename) async {
    final ok = await showDialog<bool>(context: context, builder: (dialogContext) => AlertDialog(title: const Text('Pulihkan backup?'), content: Text('Database semasa akan digantikan dengan backup $filename.'), actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Pulihkan'))]));
    if (ok != true) return;
    try { await ApiService.postAdmin('/api/admin/backups/restore', {'filename': filename}); await _load(); }
    catch (error) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$error'))); }
  }

  Future<void> _setFlag(String key, bool enabled) async {
    try { await ApiService.postAdmin('/api/admin/features', {'features': {key: enabled}}); await _load(); }
    catch (error) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$error'))); }
  }

  Future<void> _addFlag() async {
    final key = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (dialogContext) => AlertDialog(title: const Text('Tambah feature flag'), content: TextField(controller: key, decoration: const InputDecoration(labelText: 'Nama ciri / key')), actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Tambah'))]));
    if (ok == true && key.text.trim().isNotEmpty) await _setFlag(key.text.trim(), true);
    key.dispose();
  }

  Future<void> _createUser() async {
    final username = TextEditingController();
    final password = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Cipta pengguna'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: username, decoration: const InputDecoration(labelText: 'Username')),
            TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Kata laluan')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Cipta')),
        ],
      ),
    );
    if (confirmed == true) {
      try {
        await ApiService.postAdmin('/api/admin/users', {
          'username': username.text.trim(),
          'password': password.text,
        });
        await _load();
      } catch (error) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$error')));
      }
    }
    username.dispose();
    password.dispose();
  }

  Future<void> _userAction(dynamic userRecord, String action) async {
    try {
      if (action.startsWith('role_')) {
        await ApiService.postAdmin('/api/admin/users/${userRecord['id']}/role', {'role': action.substring(5)});
      } else if (action == 'reset-password') {
        final password = TextEditingController();
        final accepted = await showDialog<bool>(context: context, builder: (dialogContext) => AlertDialog(
          title: const Text('Reset kata laluan'),
          content: TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Kata laluan sementara (min. 10 aksara)')),
          actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Reset'))],
        ));
        if (accepted == true) {
          await ApiService.postAdmin('/api/admin/users/${userRecord['id']}/reset-password', {'password': password.text});
        }
        password.dispose();
      } else {
        await ApiService.postAdmin('/api/admin/users/${userRecord['id']}/$action', {});
      }
      await _load();
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$error')));
    }
  }

  Future<void> _createVoucher() async {
    final code = TextEditingController();
    final days = TextEditingController(text: '7');
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Cipta voucher'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: code, decoration: const InputDecoration(labelText: 'Kod voucher')),
            TextField(controller: days, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Tempoh (hari)')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Cipta')),
        ],
      ),
    );
    if (confirmed == true) {
      try {
        await ApiService.postAdmin('/api/admin/vouchers', {
          'code': code.text.trim(),
          'days': int.tryParse(days.text) ?? 7,
        });
        await _load();
      } catch (error) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$error')));
      }
    }
    code.dispose();
    days.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!logged) return _loginPage();
    if (mustChangePassword) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(
        title: const Text('Owner Control Center'),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
          IconButton(onPressed: _logout, icon: const Icon(Icons.logout)),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                gradient: const LinearGradient(colors: [Color(0xFF33245D), Color(0xFF191824)]),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('ZENA ADMIN', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
                  Text('Replacement Admin Control Center'),
                ],
              ),
            ),
            const SizedBox(height: 14),
            if (message.isNotEmpty) Text(message, style: const TextStyle(color: Colors.orangeAccent)),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _stat('Pengguna', stats?['users']?.toString() ?? '—'),
                _stat('Aktif', stats?['active_users']?.toString() ?? '—'),
                _stat('Voucher', vouchers.length.toString()),
                _stat('Audit', logs.length.toString()),
              ],
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                const Expanded(child: Text('Pengguna', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                FilledButton.icon(onPressed: _createUser, icon: const Icon(Icons.add), label: const Text('Tambah')),
              ],
            ),
            const SizedBox(height: 8),
            if (users.isEmpty)
              const Text('Tiada data pengguna atau backend belum disambungkan.')
            else
              ...users.map((record) => Card(
                    child: ListTile(
                      title: Text(record['username']?.toString() ?? 'Unknown'),
                      subtitle: Text('${record['role'] ?? 'USER'} • ${record['status'] ?? 'ACTIVE'}'),
                      trailing: PopupMenuButton<String>(
                        onSelected: (action) => _userAction(record, action),
                        itemBuilder: (_) => [
                          const PopupMenuItem(value: 'ban', child: Text('Sekat')),
                          const PopupMenuItem(value: 'unban', child: Text('Nyahsekat')),
                          const PopupMenuItem(value: 'delete', child: Text('Padam')),
                          const PopupMenuItem(value: 'reset-password', child: Text('Reset kata laluan')),
                          if (isSuperAdmin) const PopupMenuItem(value: 'role_ADMIN', child: Text('Jadikan Admin')),
                          if (isSuperAdmin) const PopupMenuItem(value: 'role_MODERATOR', child: Text('Jadikan Moderator')),
                          if (isSuperAdmin) const PopupMenuItem(value: 'role_USER', child: Text('Jadikan User')),
                        ],
                      ),
                    ),
                  )),
            const SizedBox(height: 18),
            Row(
              children: [
                const Expanded(child: Text('Voucher', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                FilledButton.icon(onPressed: _createVoucher, icon: const Icon(Icons.add), label: const Text('Tambah')),
              ],
            ),
            if (vouchers.isEmpty)
              const Text('Tiada voucher.')
            else
              ...vouchers.map((voucher) => ListTile(
                    leading: const Icon(Icons.confirmation_number_outlined),
                    title: Text(voucher['code']?.toString() ?? ''),
                    subtitle: Text('${voucher['days'] ?? 0} hari • ${voucher['status'] ?? 'ACTIVE'}'),
                  )),
            const SizedBox(height: 18),
            const Text('Audit Log', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            if (logs.isEmpty)
              const Text('Tiada rekod audit.')
            else
              ...logs.take(30).map((log) => ListTile(
                    dense: true,
                    leading: const Icon(Icons.history),
                    title: Text(log['action']?.toString() ?? ''),
                    subtitle: Text('${log['username'] ?? ''} • ${log['created_at'] ?? ''}'),
                  )),
            const SizedBox(height: 20),
            _sectionHeader('Kandungan', () => _createRecord('content')),
            ...contentItems.take(5).map((item) => ListTile(dense: true, leading: const Icon(Icons.article_outlined), title: Text(item['title']?.toString() ?? ''), subtitle: Text(item['kind']?.toString() ?? ''))),
            _sectionHeader('Notifikasi', () => _createRecord('notification')),
            ...notifications.take(5).map((item) => ListTile(dense: true, leading: const Icon(Icons.notifications_outlined), title: Text(item['title']?.toString() ?? ''), subtitle: Text(item['target']?.toString() ?? 'ALL'))),
            _sectionHeader('Acara', () => _createRecord('event')),
            ...events.take(5).map((item) => ListTile(dense: true, leading: const Icon(Icons.event_outlined), title: Text(item['title']?.toString() ?? ''), subtitle: Text(item['event_date']?.toString() ?? ''))),
            _sectionHeader('Polling', () => _createRecord('poll')),
            ...polls.take(5).map((item) => ListTile(dense: true, leading: const Icon(Icons.poll_outlined), title: Text(item['title']?.toString() ?? ''), subtitle: Text('${(item['options'] as List? ?? []).length} pilihan'))),
            _sectionHeader('AI Knowledge', () => _createRecord('knowledge')),
            ...knowledge.take(5).map((item) => ListTile(dense: true, leading: const Icon(Icons.psychology_outlined), title: Text(item['title']?.toString() ?? ''))),
            _sectionHeader('Feature Flags', isSuperAdmin ? _addFlag : () {}),
            ...featureFlags.map((item) => SwitchListTile(title: Text(item['key']?.toString() ?? ''), value: item['enabled'] == 1 || item['enabled'] == true, onChanged: isSuperAdmin ? (value) => _setFlag(item['key'].toString(), value) : null)),
            _sectionHeader('Backup dan Restore', isSuperAdmin ? _createBackup : () {}),
            ...backups.map((filename) => ListTile(leading: const Icon(Icons.backup_outlined), title: Text(filename.toString()), trailing: isSuperAdmin ? IconButton(tooltip: 'Pulihkan', icon: const Icon(Icons.restore), onPressed: () => _restoreBackup(filename.toString())) : null)),
            const SizedBox(height: 24),
            OutlinedButton.icon(onPressed: _exportInfo, icon: const Icon(Icons.download), label: const Text('Paparkan data ringkasan')),
          ],
        ),
      ),
    );
  }

  Widget _loginPage() {
    return Scaffold(
      appBar: AppBar(title: const Text('Admin Baharu')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.admin_panel_settings, size: 54, color: Color(0xFF9B87F5)),
                    const SizedBox(height: 12),
                    const Text('ZENA ADMIN', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 18),
                    TextField(controller: user, decoration: const InputDecoration(labelText: 'Username', border: OutlineInputBorder())),
                    const SizedBox(height: 12),
                    TextField(controller: pass, obscureText: true, decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder())),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(onPressed: busy ? null : _login, child: Text(busy ? 'Memproses...' : 'Log masuk')),
                    ),
                    if (message.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 12),
                        child: Text(message, style: const TextStyle(color: Colors.orangeAccent)),
                      ),
                    const SizedBox(height: 8),
                    const Text(
                      'API Admin berasingan: perlu jalankan/deploy folder server/.',
                      style: TextStyle(color: Colors.white54),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _sectionHeader(String title, VoidCallback onAdd) => Padding(
    padding: const EdgeInsets.only(top: 18, bottom: 6),
    child: Row(children: [Expanded(child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))), IconButton(onPressed: onAdd, icon: const Icon(Icons.add_circle_outline), tooltip: 'Tambah $title')]),
  );

  Widget _stat(String title, String value) {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 2 - 24,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(color: Colors.white60)),
              Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }

  void _exportInfo() {
    final summary = JsonEncoder.withIndent('  ').convert({
      'stats': stats,
      'users': users.length,
      'vouchers': vouchers.length,
      'audit': logs.length,
    });
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Ringkasan'),
        content: SingleChildScrollView(child: SelectableText(summary)),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Tutup'))],
      ),
    );
  }
}
