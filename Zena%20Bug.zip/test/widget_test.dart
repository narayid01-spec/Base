import 'package:flutter_test/flutter_test.dart';
import 'package:zena_v11_reconstructed/main.dart';

void main() {
  testWidgets('Zena home screen renders', (tester) async {
    await tester.pumpWidget(const ZenaApp());
    expect(find.text('ZENA V1.1'), findsOneWidget);
    expect(find.text('Akses Pantas'), findsOneWidget);
  });
}
