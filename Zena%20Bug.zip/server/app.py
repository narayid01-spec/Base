import os, sqlite3, secrets, hashlib, json, shutil, datetime
from functools import wraps
from flask import Flask, request, jsonify, g
from werkzeug.security import generate_password_hash, check_password_hash

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get('ZENA_ADMIN_DB', os.path.join(APP_DIR, 'zena_admin.sqlite3'))
BACKUP_DIR = os.environ.get('ZENA_BACKUP_DIR', os.path.join(APP_DIR, 'backups'))
app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False


def db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute('PRAGMA foreign_keys=ON')
    return g.db

@app.teardown_appcontext
def close_db(_error=None):
    conn = g.pop('db', None)
    if conn is not None: conn.close()


def audit(username, action, detail=''):
    db().execute('INSERT INTO audit_logs(username, action, detail, created_at) VALUES(?,?,?,?)',
                 (username, action, detail[:500], datetime.datetime.now(datetime.timezone.utc).isoformat()))
    db().commit()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'USER', status TEXT NOT NULL DEFAULT 'ACTIVE', must_change_password INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS tokens(token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS vouchers(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, days INTEGER NOT NULL DEFAULT 7, status TEXT NOT NULL DEFAULT 'ACTIVE', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS audit_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, action TEXT NOT NULL, detail TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS content_items(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'ACTIVE', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL, target TEXT NOT NULL DEFAULT 'ALL', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', event_date TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'ACTIVE', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS polls(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, options_json TEXT NOT NULL, votes_json TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'ACTIVE', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS ai_knowledge(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, content TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS feature_flags(key TEXT PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS login_attempts(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, ip TEXT NOT NULL, attempted_at TEXT NOT NULL);
    ''')
    columns = {row['name'] for row in conn.execute('PRAGMA table_info(users)').fetchall()}
    if 'must_change_password' not in columns:
        conn.execute('ALTER TABLE users ADD COLUMN must_change_password INTEGER NOT NULL DEFAULT 0')
    row = conn.execute('SELECT id FROM users WHERE username=?', (os.environ.get('ZENA_ADMIN_USERNAME','adam'),)).fetchone()
    if not row:
        conn.execute('INSERT INTO users(username,password_hash,role,status,must_change_password,created_at) VALUES(?,?,?,?,?,?)',
          (os.environ.get('ZENA_ADMIN_USERNAME','adam'), generate_password_hash(os.environ.get('ZENA_ADMIN_PASSWORD','7875811')), 'SUPER_ADMIN','ACTIVE',1,datetime.datetime.now(datetime.timezone.utc).isoformat()))
    conn.commit(); conn.close()


def public_user(row):
    return {'id':row['id'],'username':row['username'],'role':row['role'],'status':row['status'],'created_at':row['created_at'], 'must_change_password': bool(row['must_change_password']) if 'must_change_password' in row.keys() else False}


def require_auth(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        auth = request.headers.get('Authorization','')
        token = auth[7:].strip() if auth.lower().startswith('bearer ') else ''
        if not token: return jsonify(error='Authentication required'), 401
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        row = db().execute('SELECT u.* FROM tokens t JOIN users u ON u.id=t.user_id WHERE t.token_hash=? AND t.expires_at>?', (token_hash,datetime.datetime.now(datetime.timezone.utc).isoformat())).fetchone()
        if not row or row['status'] != 'ACTIVE': return jsonify(error='Invalid or expired session'), 401
        g.admin = row
        if row['must_change_password'] and request.path not in ('/api/auth/change-password', '/api/auth/logout'):
            return jsonify(error='Tukar kata laluan awal sebelum menggunakan Admin', must_change_password=True), 403
        return fn(*args, **kwargs)
    return wrapped


def require_role(*roles):
    def decorator(fn):
        @wraps(fn)
        @require_auth
        def wrapped(*args, **kwargs):
            if g.admin['role'] not in roles: return jsonify(error='Forbidden'), 403
            return fn(*args, **kwargs)
        return wrapped
    return decorator

@app.get('/health')
def health(): return jsonify(status='ok', service='zena-admin-api')

@app.post('/api/auth/login')
def login():
    data=request.get_json(silent=True) or {}; username=str(data.get('username','')).strip(); password=str(data.get('password',''))
    ip = (request.remote_addr or 'unknown')[:100]
    now = datetime.datetime.now(datetime.timezone.utc)
    cutoff = (now - datetime.timedelta(minutes=15)).isoformat()
    attempts = db().execute('SELECT COUNT(*) FROM login_attempts WHERE username=? AND ip=? AND attempted_at>?', (username[:100], ip, cutoff)).fetchone()[0]
    if attempts >= 10:
        return jsonify(error='Terlalu banyak percubaan. Cuba lagi selepas 15 minit.'), 429
    row=db().execute('SELECT * FROM users WHERE username=?',(username,)).fetchone()
    if not row or row['status']!='ACTIVE' or not check_password_hash(row['password_hash'],password):
        db().execute('INSERT INTO login_attempts(username,ip,attempted_at) VALUES(?,?,?)', (username[:100] or 'unknown', ip, now.isoformat()))
        db().commit()
        audit(username or 'unknown','LOGIN_FAILED','Invalid credentials')
        return jsonify(error='Username atau kata laluan tidak sah'),401
    db().execute('DELETE FROM login_attempts WHERE username=? AND ip=?', (username[:100], ip)); db().commit()
    token=secrets.token_urlsafe(36); exp=(now+datetime.timedelta(hours=12)).isoformat()
    db().execute('INSERT INTO tokens(token_hash,user_id,expires_at) VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),row['id'],exp)); db().commit()
    audit(username,'LOGIN_SUCCESS','Admin login')
    return jsonify(token=token,user=public_user(row),expires_at=exp)

@app.post('/api/auth/logout')
@require_auth
def logout():
    auth=request.headers.get('Authorization',''); token=auth[7:].strip(); db().execute('DELETE FROM tokens WHERE token_hash=?',(hashlib.sha256(token.encode()).hexdigest(),)); db().commit(); audit(g.admin['username'],'LOGOUT'); return jsonify(ok=True)

@app.post('/api/auth/change-password')
@require_auth
def change_password():
    data = request.get_json(silent=True) or {}
    current = str(data.get('current_password', ''))
    new_password = str(data.get('new_password', ''))
    row = db().execute('SELECT * FROM users WHERE id=?', (g.admin['id'],)).fetchone()
    if not row or not check_password_hash(row['password_hash'], current):
        return jsonify(error='Kata laluan semasa tidak sah'), 400
    if len(new_password) < 10:
        return jsonify(error='Kata laluan baharu mesti sekurang-kurangnya 10 aksara'), 400
    if check_password_hash(row['password_hash'], new_password):
        return jsonify(error='Gunakan kata laluan yang berbeza'), 400
    db().execute('UPDATE users SET password_hash=?, must_change_password=0 WHERE id=?', (generate_password_hash(new_password), g.admin['id']))
    token = request.headers.get('Authorization', '')[7:].strip()
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    db().execute('DELETE FROM tokens WHERE user_id=? AND token_hash<>?', (g.admin['id'], token_hash))
    db().commit()
    audit(g.admin['username'], 'PASSWORD_CHANGED', 'Initial password changed')
    return jsonify(ok=True, message='Kata laluan berjaya ditukar')

@app.get('/api/admin/stats')
@require_role('SUPER_ADMIN','ADMIN')
def stats():
    conn=db(); return jsonify(users=conn.execute('SELECT COUNT(*) FROM users').fetchone()[0],active_users=conn.execute("SELECT COUNT(*) FROM users WHERE status='ACTIVE'").fetchone()[0],banned_users=conn.execute("SELECT COUNT(*) FROM users WHERE status!='ACTIVE'").fetchone()[0],sessions=conn.execute('SELECT COUNT(*) FROM tokens').fetchone()[0])

@app.get('/api/admin/users')
@require_role('SUPER_ADMIN','ADMIN','MODERATOR')
def users():
    query = str(request.args.get('q', '')).strip()[:100]
    rows = db().execute('SELECT * FROM users WHERE username LIKE ? ORDER BY id DESC LIMIT 500', (f'%{query}%',)).fetchall()
    return jsonify(users=[public_user(r) for r in rows])

@app.post('/api/admin/users')
@require_role('SUPER_ADMIN','ADMIN')
def create_user():
    data=request.get_json(silent=True) or {}; username=str(data.get('username','')).strip(); password=str(data.get('password',''))
    if len(username)<3 or len(password)<8: return jsonify(error='Username minimum 3 aksara dan kata laluan minimum 8 aksara'),400
    role=str(data.get('role','USER')).upper()
    if role not in ('USER','MODERATOR','ADMIN'): return jsonify(error='Role tidak dibenarkan'),400
    try:
        cur=db().execute('INSERT INTO users(username,password_hash,role,status,created_at) VALUES(?,?,?,?,?)',(username,generate_password_hash(password),role,'ACTIVE',datetime.datetime.now(datetime.timezone.utc).isoformat())); db().commit()
    except sqlite3.IntegrityError: return jsonify(error='Username telah digunakan'),409
    audit(g.admin['username'],'USER_CREATED',username); row=db().execute('SELECT * FROM users WHERE id=?',(cur.lastrowid,)).fetchone(); return jsonify(user=public_user(row)),201

@app.post('/api/admin/users/bulk')
@require_role('SUPER_ADMIN', 'ADMIN')
def bulk_create_users():
    data = request.get_json(silent=True) or {}; accounts = data.get('accounts', [])
    if not isinstance(accounts, list) or not 1 <= len(accounts) <= 10:
        return jsonify(error='Hantar 1 hingga 10 akaun setiap permintaan'), 400
    created = []; skipped = []
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    for account in accounts:
        if not isinstance(account, dict):
            skipped.append({'username': '', 'reason': 'format tidak sah'}); continue
        username = str(account.get('username', '')).strip()
        password = str(account.get('password', ''))
        if len(username) < 3 or len(username) > 60 or len(password) < 8:
            skipped.append({'username': username, 'reason': 'username minimum 3 aksara dan kata laluan minimum 8 aksara'}); continue
        try:
            cur = db().execute('INSERT INTO users(username,password_hash,role,status,must_change_password,created_at) VALUES(?,?,?,?,?,?)', (username, generate_password_hash(password), 'USER', 'ACTIVE', 1, now))
            created.append({'id': cur.lastrowid, 'username': username})
        except sqlite3.IntegrityError:
            skipped.append({'username': username, 'reason': 'username telah digunakan'})
    db().commit(); audit(g.admin['username'], 'BULK_USERS_CREATED', f"created={len(created)} skipped={len(skipped)}")
    return jsonify(created=created, skipped=skipped), 201

@app.post('/api/admin/users/<int:user_id>/reset-password')
@require_role('SUPER_ADMIN', 'ADMIN')
def reset_user_password(user_id):
    data = request.get_json(silent=True) or {}; password = str(data.get('password', ''))
    if len(password) < 10: return jsonify(error='Kata laluan sementara mesti sekurang-kurangnya 10 aksara'), 400
    row = db().execute('SELECT * FROM users WHERE id=?', (user_id,)).fetchone()
    if not row: return jsonify(error='User not found'), 404
    if row['role'] == 'SUPER_ADMIN': return jsonify(error='Super Admin dilindungi'), 403
    db().execute('UPDATE users SET password_hash=?, must_change_password=1 WHERE id=?', (generate_password_hash(password), user_id))
    db().execute('DELETE FROM tokens WHERE user_id=?', (user_id,)); db().commit()
    audit(g.admin['username'], 'USER_PASSWORD_RESET', row['username'])
    return jsonify(ok=True, message='Kata laluan ditetapkan semula; pengguna mesti menukarnya selepas login')

@app.post('/api/admin/users/<int:user_id>/<action>')
@require_role('SUPER_ADMIN','ADMIN')
def user_action(user_id,action):
    row=db().execute('SELECT * FROM users WHERE id=?',(user_id,)).fetchone()
    if not row: return jsonify(error='User not found'),404
    if row['role']=='SUPER_ADMIN': return jsonify(error='Super Admin dilindungi daripada tindakan ini'),403
    if action=='ban': db().execute("UPDATE users SET status='BANNED' WHERE id=?",(user_id,))
    elif action=='unban': db().execute("UPDATE users SET status='ACTIVE' WHERE id=?",(user_id,))
    elif action=='delete': db().execute('DELETE FROM users WHERE id=?',(user_id,))
    else: return jsonify(error='Unknown action'),404
    db().commit(); audit(g.admin['username'],'USER_'+action.upper(),row['username']); return jsonify(ok=True)

@app.get('/api/admin/vouchers')
@require_role('SUPER_ADMIN','ADMIN')
def list_vouchers():
    rows=db().execute('SELECT * FROM vouchers ORDER BY id DESC').fetchall(); return jsonify(vouchers=[dict(r) for r in rows])

@app.post('/api/admin/vouchers')
@require_role('SUPER_ADMIN','ADMIN')
def create_voucher():
    data=request.get_json(silent=True) or {}; code=str(data.get('code','')).strip().upper(); days=int(data.get('days',7))
    if len(code)<3 or days<1 or days>3650: return jsonify(error='Kod atau tempoh tidak sah'),400
    try: db().execute('INSERT INTO vouchers(code,days,status,created_at) VALUES(?,?,?,?)',(code,days,'ACTIVE',datetime.datetime.now(datetime.timezone.utc).isoformat())); db().commit()
    except sqlite3.IntegrityError: return jsonify(error='Kod voucher sudah wujud'),409
    audit(g.admin['username'],'VOUCHER_CREATED',code); return jsonify(ok=True,code=code,days=days),201

@app.get('/api/admin/audit')
@require_role('SUPER_ADMIN','ADMIN')
def audit_logs():
    rows=db().execute('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 200').fetchall(); return jsonify(logs=[dict(r) for r in rows])

@app.get('/api/admin/settings')
@require_role('SUPER_ADMIN')
def get_settings(): return jsonify(settings={r['key']:r['value'] for r in db().execute('SELECT * FROM settings').fetchall()})

@app.post('/api/admin/settings')
@require_role('SUPER_ADMIN')
def set_settings():
    data=request.get_json(silent=True) or {}; changes=data.get('settings',{})
    if not isinstance(changes,dict): return jsonify(error='settings mesti objek'),400
    for k,v in changes.items(): db().execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(str(k)[:100],json.dumps(v) if not isinstance(v,str) else v))
    db().commit(); audit(g.admin['username'],'SETTINGS_UPDATED',','.join(changes.keys())); return jsonify(ok=True)

@app.post('/api/admin/backup')
@require_role('SUPER_ADMIN')
def backup():
    db().commit(); target=BACKUP_DIR; os.makedirs(target,exist_ok=True)
    filename='zena_admin_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d_%H%M%S')+'.sqlite3'; dest=os.path.join(target,filename)
    source=sqlite3.connect(DB_PATH); out=sqlite3.connect(dest); source.backup(out); out.close(); source.close(); audit(g.admin['username'],'BACKUP_CREATED',filename); return jsonify(ok=True,filename=filename)

@app.get('/api/admin/backups')
@require_role('SUPER_ADMIN', 'ADMIN')
def backups():
    target=BACKUP_DIR; os.makedirs(target,exist_ok=True); return jsonify(backups=sorted((name for name in os.listdir(target) if name.endswith('.sqlite3')),reverse=True))


@app.post('/api/admin/users/<int:user_id>/role')
@require_role('SUPER_ADMIN')
def change_user_role(user_id):
    data = request.get_json(silent=True) or {}
    role = str(data.get('role', '')).upper()
    if role not in ('USER', 'MODERATOR', 'ADMIN'):
        return jsonify(error='Role tidak dibenarkan'), 400
    row = db().execute('SELECT * FROM users WHERE id=?', (user_id,)).fetchone()
    if not row:
        return jsonify(error='User not found'), 404
    if row['role'] == 'SUPER_ADMIN':
        return jsonify(error='Super Admin dilindungi'), 403
    db().execute('UPDATE users SET role=? WHERE id=?', (role, user_id)); db().commit()
    audit(g.admin['username'], 'USER_ROLE_CHANGED', f"{row['username']} -> {role}")
    return jsonify(ok=True, role=role)

@app.delete('/api/admin/vouchers/<int:voucher_id>')
@require_role('SUPER_ADMIN', 'ADMIN')
def delete_voucher(voucher_id):
    row = db().execute('SELECT * FROM vouchers WHERE id=?', (voucher_id,)).fetchone()
    if not row: return jsonify(error='Voucher tidak ditemui'), 404
    db().execute('DELETE FROM vouchers WHERE id=?', (voucher_id,)); db().commit()
    audit(g.admin['username'], 'VOUCHER_DELETED', row['code'])
    return jsonify(ok=True)

@app.post('/api/admin/vouchers/<int:voucher_id>/status')
@require_role('SUPER_ADMIN', 'ADMIN')
def update_voucher_status(voucher_id):
    data = request.get_json(silent=True) or {}; status = str(data.get('status', '')).upper()
    if status not in ('ACTIVE', 'DISABLED'): return jsonify(error='Status tidak sah'), 400
    row = db().execute('SELECT * FROM vouchers WHERE id=?', (voucher_id,)).fetchone()
    if not row: return jsonify(error='Voucher tidak ditemui'), 404
    db().execute('UPDATE vouchers SET status=? WHERE id=?', (status, voucher_id)); db().commit()
    audit(g.admin['username'], 'VOUCHER_STATUS_CHANGED', f"{row['code']} -> {status}")
    return jsonify(ok=True, status=status)

@app.post('/api/admin/backups/restore')
@require_role('SUPER_ADMIN')
def restore_backup():
    data = request.get_json(silent=True) or {}; filename = os.path.basename(str(data.get('filename', '')))
    target = os.path.realpath(os.path.join(BACKUP_DIR, filename))
    backup_root = os.path.realpath(BACKUP_DIR)
    if not filename or not filename.endswith('.sqlite3') or not target.startswith(backup_root + os.sep) or not os.path.isfile(target):
        return jsonify(error='Fail backup tidak sah'), 400
    try:
        source = sqlite3.connect(target)
        required = {'users', 'tokens', 'vouchers', 'audit_logs', 'settings', 'content_items', 'notifications', 'events', 'polls', 'ai_knowledge', 'feature_flags', 'login_attempts'}
        present = {row[0] for row in source.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        if not required.issubset(present):
            source.close()
            return jsonify(error='Struktur backup tidak serasi dengan versi Admin ini'), 400
        # Take a safety copy before replacing the live database.
        os.makedirs(BACKUP_DIR, exist_ok=True)
        safety_name = 'pre_restore_' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d_%H%M%S') + '.sqlite3'
        safety = sqlite3.connect(os.path.join(BACKUP_DIR, safety_name))
        live = sqlite3.connect(DB_PATH)
        live.backup(safety)
        safety.close(); live.close()
        source.backup(db())
        source.close()
        audit(g.admin['username'], 'BACKUP_RESTORED', filename)
        return jsonify(ok=True, filename=filename, safety_backup=safety_name)
    except sqlite3.Error as exc:
        return jsonify(error=f'Pemulihan gagal: {exc}'), 500



@app.get('/api/admin/content')
@require_role('SUPER_ADMIN', 'ADMIN', 'MODERATOR')
def list_content():
    rows = db().execute('SELECT * FROM content_items ORDER BY id DESC LIMIT 300').fetchall()
    return jsonify(items=[dict(row) for row in rows])

@app.post('/api/admin/content')
@require_role('SUPER_ADMIN', 'ADMIN')
def create_content():
    data = request.get_json(silent=True) or {}
    kind = str(data.get('kind', 'announcement')).strip()[:40]
    title = str(data.get('title', '')).strip()[:180]
    body = str(data.get('body', '')).strip()[:10000]
    if not title: return jsonify(error='Tajuk diperlukan'), 400
    cur = db().execute('INSERT INTO content_items(kind,title,body,status,created_at) VALUES(?,?,?,?,?)', (kind, title, body, 'ACTIVE', datetime.datetime.now(datetime.timezone.utc).isoformat()))
    db().commit(); audit(g.admin['username'], 'CONTENT_CREATED', title)
    return jsonify(ok=True, id=cur.lastrowid), 201

@app.get('/api/admin/notifications')
@require_role('SUPER_ADMIN', 'ADMIN', 'MODERATOR')
def list_notifications():
    rows = db().execute('SELECT * FROM notifications ORDER BY id DESC LIMIT 300').fetchall()
    return jsonify(notifications=[dict(row) for row in rows])

@app.post('/api/admin/notifications')
@require_role('SUPER_ADMIN', 'ADMIN')
def create_notification():
    data = request.get_json(silent=True) or {}; title = str(data.get('title', '')).strip()[:180]; body = str(data.get('body', '')).strip()[:10000]; target = str(data.get('target', 'ALL')).upper()[:30]
    if not title or not body: return jsonify(error='Tajuk dan kandungan diperlukan'), 400
    cur = db().execute('INSERT INTO notifications(title,body,target,created_at) VALUES(?,?,?,?)', (title, body, target, datetime.datetime.now(datetime.timezone.utc).isoformat()))
    db().commit(); audit(g.admin['username'], 'NOTIFICATION_CREATED', title)
    return jsonify(ok=True, id=cur.lastrowid), 201

@app.get('/api/admin/events')
@require_role('SUPER_ADMIN', 'ADMIN', 'MODERATOR')
def list_events():
    return jsonify(events=[dict(row) for row in db().execute('SELECT * FROM events ORDER BY id DESC LIMIT 300').fetchall()])

@app.post('/api/admin/events')
@require_role('SUPER_ADMIN', 'ADMIN')
def create_event():
    data = request.get_json(silent=True) or {}; title = str(data.get('title', '')).strip()[:180]; description = str(data.get('description', '')).strip()[:5000]; event_date = str(data.get('event_date', '')).strip()[:80]
    if not title: return jsonify(error='Tajuk acara diperlukan'), 400
    cur = db().execute('INSERT INTO events(title,description,event_date,status,created_at) VALUES(?,?,?,?,?)', (title, description, event_date, 'ACTIVE', datetime.datetime.now(datetime.timezone.utc).isoformat()))
    db().commit(); audit(g.admin['username'], 'EVENT_CREATED', title)
    return jsonify(ok=True, id=cur.lastrowid), 201

@app.get('/api/admin/polls')
@require_role('SUPER_ADMIN', 'ADMIN', 'MODERATOR')
def list_polls():
    rows = db().execute('SELECT * FROM polls ORDER BY id DESC LIMIT 300').fetchall()
    return jsonify(polls=[{'id': row['id'], 'title': row['title'], 'options': json.loads(row['options_json']), 'votes': json.loads(row['votes_json']), 'status': row['status'], 'created_at': row['created_at']} for row in rows])

@app.post('/api/admin/polls')
@require_role('SUPER_ADMIN', 'ADMIN')
def create_poll():
    data = request.get_json(silent=True) or {}; title = str(data.get('title', '')).strip()[:180]; options = data.get('options', [])
    if not title or not isinstance(options, list) or len(options) < 2 or len(options) > 12 or any(not str(option).strip() for option in options):
        return jsonify(error='Tajuk dan 2 hingga 12 pilihan yang sah diperlukan'), 400
    options = [str(option).strip()[:180] for option in options]; votes = [0] * len(options)
    cur = db().execute('INSERT INTO polls(title,options_json,votes_json,status,created_at) VALUES(?,?,?,?,?)', (title, json.dumps(options), json.dumps(votes), 'ACTIVE', datetime.datetime.now(datetime.timezone.utc).isoformat()))
    db().commit(); audit(g.admin['username'], 'POLL_CREATED', title)
    return jsonify(ok=True, id=cur.lastrowid), 201

@app.post('/api/admin/polls/<int:poll_id>/vote')
@require_auth
def vote_poll(poll_id):
    row = db().execute('SELECT * FROM polls WHERE id=? AND status=?', (poll_id, 'ACTIVE')).fetchone()
    if not row: return jsonify(error='Polling tidak ditemui atau tidak aktif'), 404
    data = request.get_json(silent=True) or {}; choice = data.get('choice')
    options = json.loads(row['options_json']); votes = json.loads(row['votes_json'])
    if not isinstance(choice, int) or choice < 0 or choice >= len(options): return jsonify(error='Pilihan tidak sah'), 400
    votes[choice] += 1
    db().execute('UPDATE polls SET votes_json=? WHERE id=?', (json.dumps(votes), poll_id)); db().commit()
    audit(g.admin['username'], 'POLL_VOTE', str(poll_id))
    return jsonify(ok=True, votes=votes)

@app.get('/api/admin/ai-knowledge')
@require_role('SUPER_ADMIN', 'ADMIN')
def list_ai_knowledge():
    return jsonify(items=[dict(row) for row in db().execute('SELECT * FROM ai_knowledge ORDER BY id DESC LIMIT 300').fetchall()])

@app.post('/api/admin/ai-knowledge')
@require_role('SUPER_ADMIN', 'ADMIN')
def create_ai_knowledge():
    data = request.get_json(silent=True) or {}; title = str(data.get('title', '')).strip()[:180]; content = str(data.get('content', '')).strip()[:20000]
    if not title or not content: return jsonify(error='Tajuk dan kandungan diperlukan'), 400
    cur = db().execute('INSERT INTO ai_knowledge(title,content,created_at) VALUES(?,?,?)', (title, content, datetime.datetime.now(datetime.timezone.utc).isoformat()))
    db().commit(); audit(g.admin['username'], 'AI_KNOWLEDGE_CREATED', title)
    return jsonify(ok=True, id=cur.lastrowid), 201

@app.get('/api/admin/features')
@require_role('SUPER_ADMIN', 'ADMIN')
def list_feature_flags():
    return jsonify(features=[dict(row) for row in db().execute('SELECT * FROM feature_flags ORDER BY key').fetchall()])

@app.post('/api/admin/features')
@require_role('SUPER_ADMIN')
def set_feature_flags():
    data = request.get_json(silent=True) or {}; features = data.get('features', {})
    if not isinstance(features, dict): return jsonify(error='features mesti objek'), 400
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    for key, enabled in features.items():
        db().execute('INSERT INTO feature_flags(key,enabled,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET enabled=excluded.enabled,updated_at=excluded.updated_at', (str(key)[:100], 1 if bool(enabled) else 0, now))
    db().commit(); audit(g.admin['username'], 'FEATURE_FLAGS_UPDATED', ','.join(map(str, features.keys())))
    return jsonify(ok=True)


init_db()
if __name__=='__main__':
    # Set ZENA_ADMIN_PASSWORD to a strong secret before exposing this server publicly.
    app.run(host='0.0.0.0',port=int(os.environ.get('PORT','5001')),debug=False)
