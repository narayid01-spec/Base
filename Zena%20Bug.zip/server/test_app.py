"""Regression tests for the replacement Zena Admin API.
Run: python -m unittest discover -s server -p 'test_*.py'"""
import os
import tempfile
import unittest

_TEST_DIR = tempfile.TemporaryDirectory(prefix='zena-admin-tests-')
os.environ['ZENA_ADMIN_DB'] = os.path.join(_TEST_DIR.name, 'test.sqlite3')
os.environ['ZENA_ADMIN_USERNAME'] = 'adam'
os.environ['ZENA_ADMIN_PASSWORD'] = '7875811'

import app as zena  # noqa: E402
from werkzeug.security import generate_password_hash  # noqa: E402


class AdminApiTests(unittest.TestCase):
    def setUp(self):
        with zena.app.app_context():
            conn = zena.db()
            conn.execute('DELETE FROM tokens')
            conn.execute("DELETE FROM users WHERE username <> 'adam'")
            conn.execute('DELETE FROM vouchers')
            conn.execute('DELETE FROM audit_logs')
            conn.execute('DELETE FROM settings')
            conn.execute('DELETE FROM login_attempts')
            conn.execute("UPDATE users SET password_hash=?, role='SUPER_ADMIN', status='ACTIVE', must_change_password=1 WHERE username='adam'", (generate_password_hash('7875811'),))
            conn.commit()
        self.client = zena.app.test_client()

    def login(self):
        response = self.client.post('/api/auth/login', json={'username': 'adam', 'password': '7875811'})
        self.assertEqual(response.status_code, 200, response.get_json())
        return response.get_json()['token']

    def change_initial_password(self, token):
        response = self.client.post('/api/auth/change-password', headers={'Authorization': f'Bearer {token}'}, json={'current_password': '7875811', 'new_password': 'ZenaTestPass!2026'})
        self.assertEqual(response.status_code, 200, response.get_json())
        return token

    def test_health_is_public(self):
        response = self.client.get('/health')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()['status'], 'ok')

    def test_initial_password_must_be_changed_before_admin_api(self):
        token = self.login()
        blocked = self.client.get('/api/admin/stats', headers={'Authorization': f'Bearer {token}'})
        self.assertEqual(blocked.status_code, 403)
        self.change_initial_password(token)
        allowed = self.client.get('/api/admin/stats', headers={'Authorization': f'Bearer {token}'})
        self.assertEqual(allowed.status_code, 200)

    def test_admin_endpoints_require_auth(self):
        response = self.client.get('/api/admin/users')
        self.assertEqual(response.status_code, 401)

    def test_create_and_ban_user(self):
        token = self.change_initial_password(self.login())
        headers = {'Authorization': f'Bearer {token}'}
        created = self.client.post('/api/admin/users', headers=headers, json={'username': 'testuser', 'password': 'TestUserPass!2026'})
        self.assertEqual(created.status_code, 201, created.get_json())
        user_id = created.get_json()['user']['id']
        banned = self.client.post(f'/api/admin/users/{user_id}/ban', headers=headers, json={})
        self.assertEqual(banned.status_code, 200, banned.get_json())

    def test_voucher_lifecycle(self):
        token = self.change_initial_password(self.login())
        headers = {'Authorization': f'Bearer {token}'}
        created = self.client.post('/api/admin/vouchers', headers=headers, json={'code': 'TEST2026', 'days': 14})
        self.assertEqual(created.status_code, 201, created.get_json())
        listing = self.client.get('/api/admin/vouchers', headers=headers).get_json()['vouchers']
        voucher_id = next(row['id'] for row in listing if row['code'] == 'TEST2026')
        changed = self.client.post(f'/api/admin/vouchers/{voucher_id}/status', headers=headers, json={'status': 'DISABLED'})
        self.assertEqual(changed.status_code, 200)
        deleted = self.client.delete(f'/api/admin/vouchers/{voucher_id}', headers=headers)
        self.assertEqual(deleted.status_code, 200)


if __name__ == '__main__':
    unittest.main()
