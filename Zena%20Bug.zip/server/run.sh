#!/usr/bin/env sh
set -eu
python -m pip install -r requirements.txt
export ZENA_ADMIN_USERNAME="${ZENA_ADMIN_USERNAME:-adam}"
export ZENA_ADMIN_PASSWORD="${ZENA_ADMIN_PASSWORD:-7875811}"
python app.py
